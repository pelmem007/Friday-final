package com.shadiyar.friday.data

import androidx.room.Entity
import androidx.room.Fts4
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "chat_messages", indices = [Index(value = ["createdAt"])])
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val role: String,
    val content: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "knowledge_entries",
    indices = [Index(value = ["topic"]), Index(value = ["title"]), Index(value = ["externalId"], unique = true)]
)
data class KnowledgeEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val externalId: String = "",
    val title: String,
    val body: String,
    val topic: String,
    val tags: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

@Fts4(contentEntity = KnowledgeEntry::class)
@Entity(tableName = "knowledge_fts")
data class KnowledgeFts(
    val externalId: String,
    val title: String,
    val body: String,
    val topic: String,
    val tags: String
)

@Entity(tableName = "user_facts")
data class UserFact(
    @PrimaryKey val key: String,
    val value: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "planner_items", indices = [Index(value = ["triggerAt"])])
data class PlannerItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val triggerAt: Long,
    val repeatMask: Int = 0,
    val enabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "custom_commands", indices = [Index(value = ["phrase"])])
data class CustomCommand(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val phrase: String,
    val action: String,
    val argument: String = ""
)

@Entity(tableName = "imported_resources", indices = [Index(value = ["kind"])])
data class ImportedResource(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String,
    val uri: String,
    val displayName: String,
    val sizeBytes: Long = 0,
    val isSelected: Boolean = true,
    val addedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "intent_weights", primaryKeys = ["label", "token"])
data class IntentWeight(
    val label: String,
    val token: String,
    val weight: Float,
    val updatedAt: Long = System.currentTimeMillis()
)
