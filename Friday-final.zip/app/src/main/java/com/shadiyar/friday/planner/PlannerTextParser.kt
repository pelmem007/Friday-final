package com.shadiyar.friday.planner

import com.shadiyar.friday.data.PlannerItem
import java.util.Calendar

data class ParsedPlannerTask(val item: PlannerItem, val confirmation: String)

object PlannerTextParser {
    private val relative = Regex(
        "(?:таймер|напомни(?: мне)?)\\s+(?:на|через)\\s+(\\d+)\\s*(секунд\\S*|минут\\S*|час\\S*)\\s*(.*)"
    )
    private val clock = Regex(
        "(?:будильник|напомни(?: мне)?)\\s+(?:на|в)\\s+(\\d{1,2})(?:[:. ](\\d{2}))?\\s*(.*)"
    )

    fun parse(text: String): ParsedPlannerTask? {
        relative.find(text)?.let { match ->
            val amount = match.groupValues[1].toLongOrNull()?.coerceIn(1, 365L) ?: return null
            val unit = match.groupValues[2]
            val duration = when {
                unit.startsWith("сек") -> amount * 1_000
                unit.startsWith("мин") -> amount * 60_000
                else -> amount * 3_600_000
            }
            val title = match.groupValues[3].trim().ifBlank { "Таймер завершён" }
            val item = PlannerItem(title = title, triggerAt = System.currentTimeMillis() + duration)
            return ParsedPlannerTask(item, "Поставила таймер на $amount ${unit.substringBefore('н')}, Сэр.")
        }
        clock.find(text)?.let { match ->
            val hour = match.groupValues[1].toIntOrNull() ?: return null
            val minute = match.groupValues[2].toIntOrNull() ?: 0
            if (hour !in 0..23 || minute !in 0..59) return null
            val calendar = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, hour)
                set(Calendar.MINUTE, minute)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
                if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
            }
            val description = match.groupValues[3].trim().ifBlank { "Будильник" }
            return ParsedPlannerTask(
                PlannerItem(title = description, triggerAt = calendar.timeInMillis),
                "Напомню в %02d:%02d, Сэр.".format(hour, minute)
            )
        }
        return null
    }
}
