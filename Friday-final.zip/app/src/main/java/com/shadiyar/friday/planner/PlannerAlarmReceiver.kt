package com.shadiyar.friday.planner

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.shadiyar.friday.FridayApplication
import com.shadiyar.friday.MainActivity
import com.shadiyar.friday.data.FridayDatabase
import com.shadiyar.friday.service.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

class PlannerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(EXTRA_ITEM_ID, -1L)
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty().ifBlank { "Напоминание" }
        val repeatMask = intent.getIntExtra(EXTRA_REPEAT_MASK, 0)
        val openApp = android.app.PendingIntent.getActivity(
            context,
            3001,
            Intent(context, MainActivity::class.java),
            android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification = NotificationCompat.Builder(context, FridayApplication.CHANNEL_REMINDERS)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Пятница напоминает")
            .setContentText("$title, Сэр.")
            .setContentIntent(openApp)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        runCatching { NotificationHelper.post(context, (id % Int.MAX_VALUE).toInt(), notification) }

        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = FridayDatabase.get(context).dao()
                if (id >= 0 && repeatMask == 0) {
                    dao.disablePlanner(id)
                } else if (id >= 0) {
                    val next = nextMatchingDay(repeatMask)
                    val current = dao.findPlanner(id)
                    if (current != null) AlarmScheduler.schedule(context, current.copy(triggerAt = next))
                }
            } catch (error: Throwable) {
                com.shadiyar.friday.LocalErrorLog.record(context, "срабатывание напоминания", error)
            } finally {
                pending.finish()
            }
        }
    }

    private fun nextMatchingDay(mask: Int): Long {
        val now = Calendar.getInstance()
        val next = (now.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }
        repeat(8) {
            val bit = 1 shl (next.get(Calendar.DAY_OF_WEEK) - Calendar.SUNDAY)
            if (mask and bit != 0) return next.timeInMillis
            next.add(Calendar.DAY_OF_YEAR, 1)
        }
        return now.timeInMillis + 7L * 24 * 60 * 60 * 1000
    }

    companion object {
        const val EXTRA_ITEM_ID = "planner_item_id"
        const val EXTRA_TITLE = "planner_title"
        const val EXTRA_REPEAT_MASK = "planner_repeat_mask"
    }
}
