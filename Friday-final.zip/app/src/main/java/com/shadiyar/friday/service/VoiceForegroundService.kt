package com.shadiyar.friday.service

import android.Manifest
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import androidx.core.content.ContextCompat
import com.shadiyar.friday.AssistantRuntime
import com.shadiyar.friday.FridayApplication
import com.shadiyar.friday.LocalErrorLog
import com.shadiyar.friday.data.FridayDatabase
import com.shadiyar.friday.voice.VoskModelManager
import com.shadiyar.friday.voice.VoskWakeWordEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.concurrent.atomic.AtomicInteger

class VoiceForegroundService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var engine: VoskWakeWordEngine? = null
    private val notificationId = NEXT_NOTIFICATION_ID.getAndIncrement()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val notification = NotificationHelper.voice(this, "Запускаю офлайн-голосовой режим…")
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                startForeground(
                    notificationId,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(notificationId, notification)
            }
        } catch (_: SecurityException) {
            stopSelf()
            return START_NOT_STICKY
        }
        getSharedPreferences("friday_voice", MODE_PRIVATE).edit().putBoolean("running", true).apply()

        if (engine != null) return START_STICKY
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            updateNotification("Нужно разрешение на микрофон. Откройте Пятницу.")
            stopSelf()
            return START_NOT_STICKY
        }
        val model = VoskModelManager.currentModel(this)
        if (model == null) {
            updateNotification("Сначала импортируйте ZIP-модель Vosk в настройках.")
            stopSelf()
            return START_NOT_STICKY
        }
        engine = VoskWakeWordEngine(applicationContext, model).also { voice ->
            voice.start(
                onCommand = { recognized ->
                    scope.launch {
                        val answer = runCatching {
                            AssistantRuntime.handle(applicationContext, FridayDatabase.get(applicationContext).dao(), recognized)
                        }.getOrElse { "Не удалось выполнить команду, Сэр." }
                        FridayApplication.speaker.speak(applicationContext, answer)
                    }
                },
                onStatus = { status ->
                    updateNotification(status)
                    if (status.contains("остановился") || status.contains("занят")) {
                        LocalErrorLog.record(this, "голосовой сервис", IllegalStateException(status))
                    }
                }
            )
        }
        return START_STICKY
    }

    private fun updateNotification(text: String) {
        runCatching {
            NotificationHelper.post(this, notificationId, NotificationHelper.voice(this, text))
        }
    }

    override fun onDestroy() {
        getSharedPreferences("friday_voice", MODE_PRIVATE).edit().putBoolean("running", false).apply()
        engine?.stop()
        engine = null
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.shadiyar.friday.action.STOP_VOICE"
        private val NEXT_NOTIFICATION_ID = AtomicInteger(71)
    }
}
