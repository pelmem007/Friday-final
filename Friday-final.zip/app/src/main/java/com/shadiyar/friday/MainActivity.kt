package com.shadiyar.friday

import android.annotation.SuppressLint
import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.shadiyar.friday.LocalErrorLog
import com.shadiyar.friday.data.BackupManager
import com.shadiyar.friday.data.CustomCommand
import com.shadiyar.friday.data.FridayDatabase
import com.shadiyar.friday.data.ImportedResource
import com.shadiyar.friday.data.PlannerItem
import com.shadiyar.friday.brain.KnowledgeSeeder
import com.shadiyar.friday.planner.AlarmScheduler
import com.shadiyar.friday.service.FridayNotificationListener
import com.shadiyar.friday.service.OverlayBubbleService
import com.shadiyar.friday.service.VoiceForegroundService
import com.shadiyar.friday.ui.ChatScreen
import com.shadiyar.friday.ui.CommandsScreen
import com.shadiyar.friday.ui.FridayTheme
import com.shadiyar.friday.ui.KnowledgeScreen
import com.shadiyar.friday.ui.PlannerScreen
import com.shadiyar.friday.ui.SettingsScreen
import com.shadiyar.friday.ui.SystemScreen
import com.shadiyar.friday.voice.OfflineSpeechCapability
import com.shadiyar.friday.voice.OnDeviceRecognizer
import com.shadiyar.friday.voice.VoskModelManager
import com.shadiyar.friday.knowledge.ZimRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FridayTheme { FridayAppContent(intent.getBooleanExtra(EXTRA_START_VOICE, false)) } }
    }

    companion object {
        const val EXTRA_START_VOICE = "start_voice_after_boot_tap"
    }
}

private enum class FridayTab(val title: String, val marker: String) {
    CHAT("Чат", "◉"),
    KNOWLEDGE("База", "▤"),
    PLANNER("План", "◷"),
    COMMANDS("Команды", "⌘"),
    SYSTEM("Система", "⌁"),
    SETTINGS("Настройки", "⚙")
}

@Composable
private fun FridayAppContent(startVoiceOnOpen: Boolean) {
    val context = LocalContext.current
    val activity = context as? Activity
    val dao = remember { FridayDatabase.get(context).dao() }
    val scope = rememberCoroutineScope()
    val messages by dao.observeMessages().collectAsState(initial = emptyList())
    val knowledge by dao.observeKnowledge().collectAsState(initial = emptyList())
    val plannerItems by dao.observePlanner().collectAsState(initial = emptyList())
    val customCommands by dao.observeCustomCommands().collectAsState(initial = emptyList())
    val importedResources by dao.observeResources().collectAsState(initial = emptyList())
    var selectedTab by rememberSaveable { mutableStateOf(FridayTab.CHAT) }
    var status by rememberSaveable { mutableStateOf("Офлайн-режим. Скажите «привет», Сэр.") }
    var voiceRunning by rememberSaveable {
        mutableStateOf(context.getSharedPreferences("friday_voice", Context.MODE_PRIVATE).getBoolean("running", false))
    }
    var zimTitles by remember { mutableStateOf(emptyList<String>()) }
    var zimArticle by remember { mutableStateOf<com.shadiyar.friday.knowledge.ZimArticle?>(null) }
    var showOnboarding by rememberSaveable {
        mutableStateOf(!context.getSharedPreferences("friday_settings", Context.MODE_PRIVATE).getBoolean("onboarding_done", false))
    }
    var showResetConfirmation by remember { mutableStateOf(false) }
    var speakReplies by remember {
        mutableStateOf(context.getSharedPreferences("friday_settings", Context.MODE_PRIVATE).getBoolean("speak_replies", true))
    }

    val runSpeechResult: (String) -> Unit = { recognized ->
        scope.launch {
            status = runCatching { AssistantRuntime.handle(context, dao, recognized) }
                .getOrElse { "Команда не выполнена: ${it.message ?: "ошибка"}. Сэр." }
            if (speakReplies) FridayApplication.speaker.speak(context, status)
        }
    }
    val recognizer = remember(context) {
        OnDeviceRecognizer(context, runSpeechResult, { status = it })
    }
    DisposableEffect(recognizer) {
        onDispose { recognizer.destroy() }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grantMap ->
        if (grantMap[Manifest.permission.RECORD_AUDIO] == true) {
            beginVoiceSession(
                context = context,
                recognizer = recognizer,
                onStatus = { status = it },
                onRunning = { voiceRunning = it }
            )
        } else {
            status = "Для голосового ввода нужно разрешение на микрофон."
        }
    }

    val startListening = {
        if (voiceRunning) {
            context.stopService(Intent(context, VoiceForegroundService::class.java))
            recognizer.stop()
            context.getSharedPreferences("friday_voice", Context.MODE_PRIVATE).edit().putBoolean("running", false).apply()
            voiceRunning = false
            status = "Голосовой режим остановлен."
        } else {
            val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) permissions += Manifest.permission.POST_NOTIFICATIONS
            if (permissions.any { ContextCompat.checkSelfPermission(context, it) != android.content.pm.PackageManager.PERMISSION_GRANTED }) {
                status = "Нужно разрешить микрофон и уведомления."
                permissionLauncher.launch(permissions.toTypedArray())
            } else {
                beginVoiceSession(
                    context = context,
                    recognizer = recognizer,
                    onStatus = { status = it },
                    onRunning = { voiceRunning = it }
                )
            }
        }
    }

    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            context.stopService(Intent(context, VoiceForegroundService::class.java))
            recognizer.stop()
            voiceRunning = false
            status = "Проверяю и распаковываю модель Vosk…"
            runCatching {
                val model = withContext(Dispatchers.IO) { VoskModelManager.importZip(context, uri) }
                dao.clearSelectedResource("vosk")
                dao.saveResource(
                    ImportedResource(
                        kind = "vosk",
                        uri = "internal://${model.directory.name}",
                        displayName = model.directory.name,
                        sizeBytes = model.bytesWritten
                    )
                )
                status = "Модель Vosk готова к офлайн-распознаванию."
            }.onFailure { status = "Не удалось установить модель: ${it.message}" }
        }
    }
    val zimPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                ZimRepository.select(context, uri, dao)
                status = "ZIM-файл выбран. Можно искать заголовки статей без интернета."
            }.onFailure { status = "Не удалось открыть ZIM: ${it.message}" }
        }
    }
    val knowledgePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val source = readTextLimited(context, uri, 20 * 1024 * 1024)
                val title = uri.lastPathSegment ?: "custom-pack.json"
                val count = KnowledgeSeeder.importJson(context, dao, title, source)
                status = "Импортировано записей: $count."
            }.onFailure { status = "Не удалось импортировать JSON-пак: ${it.message}" }
        }
    }
    val backupExportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val content = withContext(Dispatchers.IO) { BackupManager.export(dao) }
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(content) }
                    ?: error("Не удалось создать файл.")
                status = "Резервная копия сохранена."
            }.onFailure { status = "Ошибка экспорта: ${it.message}" }
        }
    }
    val backupImportPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                val content = readTextLimited(context, uri, 20 * 1024 * 1024)
                val count = BackupManager.restore(context, dao, content)
                status = "Восстановлено записей: $count. Время напоминаний зависит от разрешения Android."
            }.onFailure { status = "Ошибка импорта резервной копии: ${it.message}" }
        }
    }

    LaunchedEffect(Unit) {
        runCatching {
            KnowledgeSeeder.ensureBuiltInPacks(context, dao)
            ZimRepository.reopenSelected(context, dao)
        }.onFailure { status = "Не удалось загрузить локальные данные: ${it.message}" }
        if (startVoiceOnOpen) {
            status = "Нажмите кнопку микрофона, чтобы запустить прослушивание."
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    FridayTab.entries.forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = { Text(tab.marker, fontFamily = FontFamily.Monospace, fontSize = 18.sp) },
                            label = { Text(tab.title, fontFamily = FontFamily.Monospace, fontSize = 9.sp, maxLines = 1) }
                        )
                    }
                }
            }
        ) { insets ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(insets)
            ) {
                Header(status = status, voiceRunning = voiceRunning)
                when (selectedTab) {
                    FridayTab.CHAT -> ChatScreen(
                        messages = messages,
                        status = status,
                        voiceRunning = voiceRunning,
                        onSend = { text ->
                            scope.launch {
                                status = runCatching { AssistantRuntime.handle(context, dao, text) }
                                    .getOrElse { "Ошибка команды: ${it.message ?: "неизвестно"}. Сэр." }
                                if (speakReplies) FridayApplication.speaker.speak(context, status)
                            }
                        },
                        onVoice = { startListening() },
                        onReadLastNotification = {
                            val last = FridayNotificationListener.latest(context)
                            if (last.isNullOrBlank()) status = "Новых уведомлений пока нет, Сэр."
                            else {
                                status = "Последнее уведомление: $last"
                                if (speakReplies) FridayApplication.speaker.speak(context, status)
                            }
                        }
                    )
                    FridayTab.KNOWLEDGE -> KnowledgeScreen(
                        dao = dao,
                        knowledge = knowledge,
                        resources = importedResources,
                        onImportPack = { knowledgePicker.launch(arrayOf("application/json", "text/json", "*/*")) },
                        onPickZim = { zimPicker.launch(arrayOf("application/octet-stream", "application/x-zim", "*/*")) },
                        zimTitles = zimTitles,
                        article = zimArticle,
                        onFindZim = { query ->
                            scope.launch {
                                status = "Ищу заголовки статей в ZIM…"
                                zimTitles = runCatching { ZimRepository.searchTitles(query) }.getOrElse {
                                    status = "Ошибка чтения ZIM: ${it.message}"
                                    emptyList()
                                }
                                if (zimTitles.isEmpty()) status = "Подходящих заголовков не найдено."
                            }
                        },
                        onOpenZimTitle = { title ->
                            scope.launch {
                                zimArticle = runCatching { ZimRepository.openTitle(title) }.getOrElse {
                                    status = "Не удалось открыть статью: ${it.message}"
                                    null
                                }
                                if (zimArticle == null) status = "Статья слишком велика или недоступна в этом архиве."
                            }
                        },
                        status = { status = it }
                    )
                    FridayTab.PLANNER -> PlannerScreen(
                        items = plannerItems,
                        onAdd = { title, minutes, repeatMask ->
                            scope.launch {
                                runCatching {
                                    val baseTime = System.currentTimeMillis() + minutes.coerceIn(1, 525_600) * 60_000L
                                    val at = if (repeatMask == 0) baseTime else {
                                        java.util.Calendar.getInstance().apply {
                                            timeInMillis = baseTime
                                            repeat(7) {
                                                val bit = 1 shl (get(java.util.Calendar.DAY_OF_WEEK) - java.util.Calendar.SUNDAY)
                                                if (repeatMask and bit == 0) add(java.util.Calendar.DAY_OF_YEAR, 1)
                                                else return@apply
                                            }
                                        }.timeInMillis
                                    }
                                    val id = dao.insertPlanner(PlannerItem(title = title, triggerAt = at, repeatMask = repeatMask))
                                    val saved = PlannerItem(id = id, title = title, triggerAt = at, repeatMask = repeatMask)
                                    if (!AlarmScheduler.schedule(context, saved)) {
                                        status = "Добавлено; точное время может зависеть от разрешения Android."
                                    } else status = "Напоминание добавлено, Сэр."
                                }.onFailure { status = "Не удалось добавить напоминание: ${it.message}" }
                            }
                        },
                        onDelete = { item ->
                            scope.launch {
                                AlarmScheduler.cancel(context, item.id)
                                dao.deletePlanner(item.id)
                                status = "Напоминание удалено."
                            }
                        },
                        onOpenExactAlarmSettings = { openExactAlarmSettings(context) }
                    )
                    FridayTab.COMMANDS -> CommandsScreen(
                        commands = customCommands,
                        onAdd = { phrase, action, argument ->
                            scope.launch {
                                dao.saveCustomCommand(CustomCommand(phrase = phrase, action = action, argument = argument))
                                status = "Пользовательская команда сохранена."
                            }
                        },
                        onDelete = { command -> scope.launch { dao.deleteCustomCommand(command) } }
                    )
                    FridayTab.SYSTEM -> SystemScreen(
                        modelReady = VoskModelManager.currentModel(context) != null,
                        zimReady = importedResources.any { it.kind == "zim" && it.isSelected },
                        onStartVoice = { startListening() },
                        onRequestOverlay = {
                            if (!Settings.canDrawOverlays(context)) {
                                openSettings(context, Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
                            } else {
                                context.startService(Intent(context, OverlayBubbleService::class.java))
                                status = "Плавающая кнопка запущена. Остановить её можно в этом разделе."
                            }
                        },
                        onStopOverlay = {
                            context.stopService(Intent(context, OverlayBubbleService::class.java))
                            status = "Плавающая кнопка остановлена."
                        },
                        onOpenNotifications = { openSettings(context, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) },
                        onOpenExactAlarms = { openExactAlarmSettings(context) },
                        onBattery = {
                            val intent = context.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                            val level = intent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
                            val scale = intent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100) ?: 100
                            status = if (level >= 0 && scale > 0) "Заряд батареи: ${level * 100 / scale}%." else "Не удалось прочитать заряд."
                        },
                        onBatteryOptimization = { openBatteryOptimization(context) },
                        onAutoStartHelp = { status = "Infinix XOS: откройте настройки приложения → Управление питанием/Автозапуск; разрешите автозапуск и работу в фоне. Названия пунктов зависят от версии XOS." }
                    )
                    FridayTab.SETTINGS -> SettingsScreen(
                        resources = importedResources,
                        speakReplies = speakReplies,
                        onSpeakRepliesChanged = { enabled ->
                            speakReplies = enabled
                            context.getSharedPreferences("friday_settings", Context.MODE_PRIVATE).edit().putBoolean("speak_replies", enabled).apply()
                        },
                        onImportModel = { modelPicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                        onImportZim = { zimPicker.launch(arrayOf("application/octet-stream", "application/x-zim", "*/*")) },
                        onImportPack = { knowledgePicker.launch(arrayOf("application/json", "text/json", "*/*")) },
                        onExport = { backupExportPicker.launch("friday-backup.json") },
                        onImport = { backupImportPicker.launch(arrayOf("application/json", "text/json", "*/*")) },
                        onReset = { showResetConfirmation = true },
                        status = status
                    )
                }
            }
        }
    }

    if (showOnboarding) {
        AlertDialog(
            onDismissRequest = { },
            title = { Text("Первый запуск") },
            text = {
                Column {
                    Text("Пятница работает локально. Для голоса импортируйте ZIP-модель Vosk и отдельно разрешите микрофон.")
                    Spacer(Modifier.height(8.dp))
                    Text("Android 15 не разрешает автоматически включать микрофонный сервис после перезагрузки. В XOS также может понадобиться разрешить автозапуск и фоновую работу.")
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    showOnboarding = false
                    context.getSharedPreferences("friday_settings", Context.MODE_PRIVATE).edit().putBoolean("onboarding_done", true).apply()
                    selectedTab = FridayTab.SYSTEM
                    status = "Проверьте разрешения и настройки Infinix XOS."
                }) { Text("Перейти к разрешениям") }
            },
            dismissButton = {
                TextButton(onClick = {
                    showOnboarding = false
                    context.getSharedPreferences("friday_settings", Context.MODE_PRIVATE).edit().putBoolean("onboarding_done", true).apply()
                }) { Text("Пока пропустить") }
            },
            containerColor = MaterialTheme.colorScheme.surface
        )
    }

    if (showResetConfirmation) {
        AlertDialog(
            onDismissRequest = { showResetConfirmation = false },
            title = { Text("Полный сброс") },
            text = { Text("Будут удалены история чата, заметки, задачи, команды, импортированные JSON-паки и модель Vosk, а доступ к выбранному ZIM будет отозван. Сам файл ZIM останется в хранилище телефона. Это действие нельзя отменить.") },
            confirmButton = {
                TextButton(onClick = {
                    showResetConfirmation = false
                    scope.launch {
                        runCatching {
                            context.stopService(Intent(context, VoiceForegroundService::class.java))
                            context.stopService(Intent(context, OverlayBubbleService::class.java))
                            recognizer.stop()
                            dao.allPlannerForBackup().forEach { AlarmScheduler.cancel(context, it.id) }
                            dao.clearMessages()
                            dao.clearFacts()
                            dao.clearPlanner()
                            dao.clearCommands()
                            dao.clearResources()
                            dao.clearWeights()
                            dao.clearKnowledge()
                            KnowledgeSeeder.ensureBuiltInPacks(context, dao)
                            importedResources.filter { it.kind == "zim" }.forEach { resource ->
                                runCatching {
                                    context.contentResolver.releasePersistableUriPermission(
                                        Uri.parse(resource.uri),
                                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                                    )
                                }
                            }
                            ZimRepository.close()
                            File(context.filesDir, "vosk-model").deleteRecursively()
                            File(context.filesDir, "vosk-model-staging").deleteRecursively()
                            LocalErrorLog.clear(context)
                            context.getSharedPreferences("friday_settings", Context.MODE_PRIVATE).edit().clear().apply()
                            context.getSharedPreferences("friday_zim", Context.MODE_PRIVATE).edit().clear().apply()
                            context.getSharedPreferences("friday_notifications", Context.MODE_PRIVATE).edit().clear().apply()
                            context.getSharedPreferences("friday_voice", Context.MODE_PRIVATE).edit().clear().apply()
                            speakReplies = true
                            voiceRunning = false
                            showOnboarding = true
                            selectedTab = FridayTab.CHAT
                            status = "Локальные данные сброшены."
                        }.onFailure { status = "Не удалось выполнить сброс: ${it.message}" }
                    }
                }) { Text("Удалить данные") }
            },
            dismissButton = { TextButton(onClick = { showResetConfirmation = false }) { Text("Отмена") } },
            containerColor = MaterialTheme.colorScheme.surface
        )
    }
}

@Composable
private fun Header(status: String, voiceRunning: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("ПЯТНИЦА // OFFLINE", color = MaterialTheme.colorScheme.primary, fontFamily = FontFamily.Monospace, fontSize = 15.sp)
            Text(if (voiceRunning) "МИКРОФОН АКТИВЕН" else "ГОТОВА", color = if (voiceRunning) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurfaceVariant, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
        }
        Text(status.take(180), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp, maxLines = 2, modifier = Modifier.padding(top = 5.dp))
    }
}

private fun beginVoiceSession(
    context: Context,
    recognizer: OnDeviceRecognizer,
    onStatus: (String) -> Unit,
    onRunning: (Boolean) -> Unit
) {
    val preferAndroid = context.getSharedPreferences("friday_settings", Context.MODE_PRIVATE)
        .getString("speech_engine", "vosk") == "android"
    if (preferAndroid) {
        recognizer.start()
    } else if (VoskModelManager.currentModel(context) != null) {
        val service = Intent(context, VoiceForegroundService::class.java)
        try {
            ContextCompat.startForegroundService(context, service)
            context.getSharedPreferences("friday_voice", Context.MODE_PRIVATE).edit().putBoolean("running", true).apply()
            onRunning(true)
            onStatus("Запускаю прослушивание. Скажите «Пятница», Сэр.")
        } catch (_: Exception) {
            onStatus("Android не разрешил запустить фоновый микрофон. Запустите режим из открытого приложения.")
        }
    } else if (OfflineSpeechCapability.isAvailable(context)) {
        recognizer.start()
    } else {
        onStatus("Импортируйте ZIP-модель Vosk, чтобы включить офлайн-распознавание.")
    }
}

private fun openSettings(context: Context, action: String, uri: Uri? = null) {
    runCatching {
        val intent = if (uri == null) Intent(action) else Intent(action, uri)
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

private fun openExactAlarmSettings(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        openSettings(
            context,
            Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
            Uri.parse("package:${context.packageName}")
        )
    } else {
        openSettings(context, Settings.ACTION_SETTINGS)
    }
}

@SuppressLint("BatteryLife")
private fun openBatteryOptimization(context: Context) {
    runCatching {
        val intent = Intent(
            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
            Uri.parse("package:${context.packageName}")
        )
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

private suspend fun readTextLimited(context: Context, uri: Uri, limitBytes: Int): String =
    withContext(Dispatchers.IO) {
        val input = context.contentResolver.openInputStream(uri) ?: error("Не удалось открыть выбранный файл.")
        val output = ByteArrayOutputStream()
        input.use { stream ->
            val buffer = ByteArray(32 * 1024)
            while (true) {
                val count = stream.read(buffer)
                if (count < 0) break
                require(output.size() + count <= limitBytes) { "Файл больше допустимого размера ${limitBytes / (1024 * 1024)} МБ." }
                output.write(buffer, 0, count)
            }
        }
        output.toString(Charsets.UTF_8.name())
    }
