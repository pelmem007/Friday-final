package com.shadiyar.friday.brain

import android.content.Context
import com.shadiyar.friday.data.FridayDao
import com.shadiyar.friday.data.KnowledgeEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray

/** Загружает небольшие независимые JSON-паки, не держит базу знаний целиком в памяти. */
object KnowledgeSeeder {
    private val builtInPacks = listOf("core.json", "facts.json", "jokes.json", "extra.json")

    suspend fun ensureBuiltInPacks(context: Context, dao: FridayDao) = withContext(Dispatchers.IO) {
        for (pack in builtInPacks) {
            val json = context.assets.open("knowledge/$pack").bufferedReader().use { it.readText() }
            insertPack(dao, pack, json)
        }
    }

    suspend fun importJson(context: Context, dao: FridayDao, displayName: String, json: String): Int =
        withContext(Dispatchers.IO) { insertPack(dao, displayName, json) }

    private suspend fun insertPack(dao: FridayDao, packName: String, raw: String): Int {
        val source = raw.trim()
        val array = if (source.startsWith("[")) JSONArray(source)
        else org.json.JSONObject(source).optJSONArray("entries")
            ?: throw IllegalArgumentException("В JSON не найден массив entries")
        require(array.length() <= 25_000) { "В одном паке допускается не более 25 000 записей." }
        var inserted = 0
        for (i in 0 until array.length()) {
            val item = array.optJSONObject(i) ?: continue
            val title = item.optString("title").trim()
            val body = item.optString("body").trim()
            if (title.isBlank() || body.isBlank()) continue
            val tagsValue = item.opt("tags")
            val tags = when (tagsValue) {
                is JSONArray -> (0 until tagsValue.length()).map { tagsValue.optString(it) }.joinToString(" ")
                is String -> tagsValue
                else -> ""
            }
            val id = item.optString("id").takeIf { it.isNotBlank() } ?: "$packName:$i"
            val rowId = dao.insertKnowledge(
                KnowledgeEntry(
                    externalId = id,
                    title = title.take(300),
                    body = body.take(40_000),
                    topic = item.optString("topic", "общее").ifBlank { "общее" }.take(100),
                    tags = tags.take(500)
                )
            )
            if (rowId != -1L) inserted++
        }
        return inserted
    }
}
