package com.shadiyar.friday.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import com.shadiyar.friday.planner.AlarmScheduler

/** Резервная копия пользовательских данных. Системные разрешения и внешние URI в неё не включаются. */
object BackupManager {
    suspend fun export(dao: FridayDao): String {
        val root = JSONObject()
            .put("format", "friday-backup")
            .put("version", 1)
        root.put("messages", JSONArray().apply {
            dao.allMessagesForBackup().asReversed().forEach { item ->
                put(JSONObject().put("role", item.role).put("content", item.content).put("createdAt", item.createdAt))
            }
        })
        root.put("facts", JSONArray().apply {
            dao.allFactsForBackup().forEach { put(JSONObject().put("key", it.key).put("value", it.value).put("updatedAt", it.updatedAt)) }
        })
        root.put("planner", JSONArray().apply {
            dao.allPlannerForBackup().forEach {
                put(JSONObject().put("title", it.title).put("triggerAt", it.triggerAt).put("repeatMask", it.repeatMask).put("enabled", it.enabled).put("createdAt", it.createdAt))
            }
        })
        root.put("commands", JSONArray().apply {
            dao.getCustomCommands().forEach {
                put(JSONObject().put("phrase", it.phrase).put("action", it.action).put("argument", it.argument))
            }
        })
        return root.toString(2)
    }

    suspend fun restore(context: Context, dao: FridayDao, source: String): Int {
        require(source.length <= 20 * 1024 * 1024) { "Файл резервной копии больше 20 МБ." }
        val root = JSONObject(source)
        require(root.optString("format") == "friday-backup") { "Это не резервная копия Пятницы." }
        require(root.optInt("version") == 1) { "Версия резервной копии не поддерживается." }
        var imported = 0
        root.optJSONArray("facts")?.let { array ->
            val facts = (0 until array.length()).mapNotNull { index ->
                val item = array.optJSONObject(index) ?: return@mapNotNull null
                val key = item.optString("key")
                val value = item.optString("value")
                if (key.isBlank() || value.isBlank()) null else UserFact(key, value, item.optLong("updatedAt", System.currentTimeMillis()))
            }
            dao.restoreFacts(facts)
            imported += facts.size
        }
        root.optJSONArray("planner")?.let { array ->
            val items = (0 until array.length()).mapNotNull { index ->
                val item = array.optJSONObject(index) ?: return@mapNotNull null
                val title = item.optString("title")
                val whenMillis = item.optLong("triggerAt")
                if (title.isBlank() || whenMillis <= 0) null else PlannerItem(
                    title = title,
                    triggerAt = whenMillis,
                    repeatMask = item.optInt("repeatMask"),
                    enabled = item.optBoolean("enabled", true),
                    createdAt = item.optLong("createdAt", System.currentTimeMillis())
                )
            }
            items.forEach { item ->
                val id = dao.insertPlanner(item)
                AlarmScheduler.schedule(context, item.copy(id = id))
            }
            imported += items.size
        }
        root.optJSONArray("commands")?.let { array ->
            val commands = (0 until array.length()).mapNotNull { index ->
                val item = array.optJSONObject(index) ?: return@mapNotNull null
                val phrase = item.optString("phrase")
                val action = item.optString("action")
                if (phrase.isBlank() || action.isBlank()) null else CustomCommand(phrase = phrase, action = action, argument = item.optString("argument"))
            }
            dao.restoreCustomCommands(commands)
            imported += commands.size
        }
        root.optJSONArray("messages")?.let { array ->
            val messages = (0 until array.length()).mapNotNull { index ->
                val item = array.optJSONObject(index) ?: return@mapNotNull null
                val role = item.optString("role")
                val content = item.optString("content")
                if (role !in setOf("user", "assistant") || content.isBlank()) null
                else ChatMessage(role = role, content = content, createdAt = item.optLong("createdAt", System.currentTimeMillis()))
            }
            messages.takeLast(100).forEach { dao.addMessage(it) }
            imported += messages.size.coerceAtMost(100)
        }
        return imported
    }
}
