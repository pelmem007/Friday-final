package com.shadiyar.friday.actions

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.shadiyar.friday.brain.PhoneAction
import java.util.Calendar

/** Вызывает только публичные системные действия; закрытые переключатели ОС не обходятся. */
object PhoneActions {
    fun perform(context: Context, action: PhoneAction): String = when (action.kind) {
        "OPEN_APP" -> openApp(context, action.argument)
        "CALL" -> dial(context, action.argument)
        "SMS" -> createSms(context, action.argument)
        "MAP" -> openUri(context, Uri.parse("geo:0,0?q=${Uri.encode(action.argument)}"), "Не удалось открыть карту, Сэр.")
        "WEB" -> openUri(context, Uri.parse("https://www.google.com/search?q=${Uri.encode(action.argument)}"), "Браузер не найден, Сэр.")
        "TORCH_ON" -> torch(context, true)
        "TORCH_OFF" -> torch(context, false)
        "VOLUME_UP", "VOLUME_DOWN" -> volume(context, action.kind == "VOLUME_UP")
        "BATTERY" -> battery(context)
        "WIFI_SETTINGS" -> if (android.os.Build.VERSION.SDK_INT >= 29) {
            settings(context, Settings.Panel.ACTION_WIFI)
        } else {
            settings(context, Settings.ACTION_WIFI_SETTINGS)
        }
        "BLUETOOTH_SETTINGS" -> settings(context, Settings.ACTION_BLUETOOTH_SETTINGS)
        "AIRPLANE_SETTINGS" -> settings(context, Settings.ACTION_AIRPLANE_MODE_SETTINGS)
        "DND_SETTINGS" -> settings(context, Settings.ACTION_ZEN_MODE_PRIORITY_SETTINGS)
        "DISPLAY_SETTINGS" -> settings(context, Settings.ACTION_DISPLAY_SETTINGS)
        "CAMERA" -> start(context, Intent(MediaStore.ACTION_IMAGE_CAPTURE), "Открываю камеру, Сэр.")
        "CALENDAR" -> calendar(context, action.argument)
        else -> "Это действие пока недоступно, Сэр."
    }

    @SuppressLint("QueryPermissionsNeeded")
    private fun openApp(context: Context, request: String): String {
        val aliases = mapOf(
            "ютуб" to listOf("youtube", "youtube"),
            "ютюб" to listOf("youtube", "youtube"),
            "youtube" to listOf("youtube", "youtube"),
            "карты" to listOf("maps", "карты"),
            "камера" to listOf("camera", "камера"),
            "калькулятор" to listOf("calculator", "калькулятор"),
            "браузер" to listOf("chrome", "браузер"),
            "хром" to listOf("chrome", "chrome")
        )
        val terms = aliases[request.lowercase()] ?: listOf(request.lowercase())
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(launcher, PackageManager.MATCH_ALL).firstOrNull { info ->
            val label = info.loadLabel(pm).toString().lowercase()
            terms.any { term -> label == term || (term.length >= 4 && label.contains(term)) }
        } ?: return "Не нашла приложение «$request» на этом телефоне, Сэр."
        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            ?: return "Не получилось открыть «$request», Сэр."
        return start(context, intent, "Открываю ${match.loadLabel(pm)}, Сэр.")
    }

    private fun dial(context: Context, who: String): String {
        val number = who.filter(Char::isDigit).takeIf { it.length >= 5 } ?: findContactNumber(context, who)
            ?: return "Не нашла номер «$who». Для поиска имени разрешите доступ к контактам, Сэр."
        return openUri(context, Uri.parse("tel:${Uri.encode(number)}"), "Не удалось открыть набор номера, Сэр.", Intent.ACTION_DIAL)
    }

    private fun findContactNumber(context: Context, name: String): String? {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        return runCatching {
            context.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%${name.trim()}%"),
                null
            )?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
        }.getOrNull()
    }

    private fun createSms(context: Context, value: String): String {
        val parts = value.split("|", limit = 2)
        if (parts.size != 2) return "Скажите: «напиши смс [номер] текст [сообщение]», Сэр."
        val number = parts[0].filter(Char::isDigit)
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$number"))
            .putExtra("sms_body", parts[1])
        return start(context, intent, "Открылось сообщение. Проверьте и нажмите «Отправить», Сэр.")
    }

    private fun torch(context: Context, enabled: Boolean): String = try {
        val manager = context.getSystemService(CameraManager::class.java)
        val camera = manager.cameraIdList.firstOrNull {
            manager.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        } ?: return "На телефоне нет вспышки, Сэр."
        manager.setTorchMode(camera, enabled)
        if (enabled) "Фонарик включён, Сэр." else "Фонарик выключен, Сэр."
    } catch (_: SecurityException) {
        "Разрешите доступ к камере, чтобы управлять фонариком, Сэр."
    } catch (_: Exception) {
        "Не получилось управлять фонариком, Сэр."
    }

    private fun volume(context: Context, up: Boolean): String = runCatching {
        context.getSystemService(AudioManager::class.java).adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            0
        )
        if (up) "Громкость увеличена, Сэр." else "Громкость уменьшена, Сэр."
    }.getOrDefault("Не удалось изменить громкость, Сэр.")

    private fun battery(context: Context): String {
        val intent = context.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = intent?.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = intent?.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100) ?: 100
        if (level < 0 || scale <= 0) return "Не удалось проверить заряд, Сэр."
        return "Заряд батареи ${level * 100 / scale} процентов, Сэр."
    }

    private fun calendar(context: Context, title: String): String {
        val intent = Intent(Intent.ACTION_INSERT, CalendarContract.Events.CONTENT_URI)
            .putExtra(CalendarContract.Events.TITLE, title.take(120))
            .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, Calendar.getInstance().timeInMillis)
        return start(context, intent, "Открыла создание события в календаре, Сэр.")
    }

    private fun settings(context: Context, action: String): String {
        val intent = Intent(action)
        return start(context, intent, "Открываю системные настройки, Сэр.")
    }

    private fun openUri(
        context: Context,
        uri: Uri?,
        failure: String,
        action: String = Intent.ACTION_VIEW
    ): String {
        val intent = if (uri == null) Intent(action) else Intent(action, uri)
        return start(context, intent, failure)
    }

    private fun start(context: Context, intent: Intent, success: String): String = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        success
    } catch (_: Exception) {
        "Android не разрешил открыть этот экран из текущего состояния. Откройте приложение «Пятница» и повторите, Сэр."
    }
}
