package com.shadiyar.friday.service

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.content.Context

/** Сохраняет только последнее уведомление локально после явного включения доступа пользователем. */
class FridayNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val notification = sbn?.notification ?: return
        val extras = notification.extras
        val title = extras.getCharSequence(android.app.Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(android.app.Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_LAST, "$title. $text".trim().take(500))
            .apply()
    }

    companion object {
        private const val PREFS = "friday_notifications"
        private const val KEY_LAST = "last"

        fun latest(context: Context): String? = context
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_LAST, null)
    }
}
