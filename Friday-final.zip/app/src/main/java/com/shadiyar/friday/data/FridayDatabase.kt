package com.shadiyar.friday.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ChatMessage::class,
        KnowledgeEntry::class,
        KnowledgeFts::class,
        UserFact::class,
        PlannerItem::class,
        CustomCommand::class,
        ImportedResource::class,
        IntentWeight::class
    ],
    version = 1,
    exportSchema = true
)
abstract class FridayDatabase : RoomDatabase() {
    abstract fun dao(): FridayDao

    companion object {
        @Volatile private var instance: FridayDatabase? = null

        fun get(context: Context): FridayDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                FridayDatabase::class.java,
                "friday_local.db"
            ).build().also { instance = it }
        }
    }
}
