package com.shadiyar.friday.knowledge

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.webkit.WebResourceResponse
import com.shadiyar.friday.data.FridayDao
import com.shadiyar.friday.data.ImportedResource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.kiwix.libzim.Archive
import org.kiwix.libzim.EntryNotFoundException
import java.io.ByteArrayInputStream
import java.nio.charset.StandardCharsets

data class ZimArticle(val title: String, val path: String, val mimeType: String, val html: String)

/** Читает выбранный ZIM напрямую по файловому дескриптору — без копии многогигабайтного файла. */
object ZimRepository {
    private const val PREFS = "friday_zim"
    private const val KEY_URI = "selected_uri"
    private const val MAX_ARTICLE_BYTES = 5L * 1024 * 1024
    private const val MAX_WEB_RESOURCE_BYTES = 8L * 1024 * 1024
    private val lock = Any()
    @Volatile private var descriptor: ParcelFileDescriptor? = null
    @Volatile private var archive: Archive? = null
    @Volatile private var appContext: Context? = null

    suspend fun select(context: Context, uri: Uri, dao: FridayDao): ImportedResource =
        withContext(Dispatchers.IO) {
            val pfd = context.contentResolver.openFileDescriptor(uri, "r")
                ?: throw IllegalArgumentException("Файл недоступен для чтения.")
            val opened = try {
                Archive(pfd.fileDescriptor)
            } catch (error: Throwable) {
                pfd.close()
                throw IllegalArgumentException("Файл не открылся как ZIM. Выберите корректный архив Kiwix.", error)
            }
            synchronized(lock) {
                closeCurrent()
                descriptor = pfd
                archive = opened
                appContext = context.applicationContext
            }
            val name = displayName(context, uri)
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_URI, uri.toString()).apply()
            dao.clearSelectedResource("zim")
            val resource = ImportedResource(
                kind = "zim",
                uri = uri.toString(),
                displayName = name,
                sizeBytes = pfd.statSize.coerceAtLeast(0),
                isSelected = true
            )
            dao.saveResource(resource)
            resource
        }

    suspend fun reopenSelected(context: Context, dao: FridayDao) = withContext(Dispatchers.IO) {
        val stored = dao.selectedResource("zim")
            ?: context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_URI, null)?.let {
                ImportedResource(kind = "zim", uri = it, displayName = "Офлайн-библиотека")
            }
            ?: return@withContext
        runCatching { select(context, Uri.parse(stored.uri), dao) }
    }

    suspend fun searchTitles(query: String): List<String> = withContext(Dispatchers.IO) {
        synchronized(lock) {
            val zim = archive ?: return@withContext emptyList()
            val clean = query.trim().take(100)
            if (clean.isBlank()) return@withContext emptyList()
            val titles = LinkedHashSet<String>()
            runCatching {
                if (zim.hasEntryByTitle(clean)) titles.add(zim.getEntryByTitle(clean).title)
            }
            runCatching {
                val iterator = zim.findByTitle(clean)
                try {
                    while (iterator.hasNext() && titles.size < 20) titles.add(iterator.next().title)
                } finally {
                    iterator.dispose()
                }
            }
            titles.toList()
        }
    }

    suspend fun openTitle(title: String): ZimArticle? = withContext(Dispatchers.IO) {
        synchronized(lock) {
            val zim = archive ?: return@withContext null
            val entry = runCatching { zim.getEntryByTitle(title) }.getOrNull() ?: return@withContext null
            article(entry.path)
        }
    }

    fun intercept(path: String): WebResourceResponse {
        val safePath = runCatching { Uri.decode(path) }
            .getOrDefault(path)
            .removePrefix("/")
        val item = synchronized(lock) {
            val zim = archive ?: return WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream(byteArrayOf()))
            runCatching {
                if (!zim.hasEntryByPath(safePath)) null
                else {
                    val entry = zim.getEntryByPath(safePath)
                    val resource = entry.getItem(true)
                    val blob = resource.data
                    val size = blob.size()
                    if (size > MAX_WEB_RESOURCE_BYTES) {
                        blob.dispose()
                        null
                    } else {
                        val data = blob.data
                        val mime = resource.mimetype
                        blob.dispose()
                        Pair(mime, data)
                    }
                }
            }.getOrNull()
        }
        return if (item == null) {
            WebResourceResponse("text/plain", "UTF-8", ByteArrayInputStream("Материал недоступен или слишком велик.".toByteArray()))
        } else {
            WebResourceResponse(item.first.ifBlank { "application/octet-stream" }, "UTF-8", ByteArrayInputStream(item.second))
        }
    }

    fun isOpen(): Boolean = archive != null

    fun close() {
        synchronized(lock) { closeCurrent() }
    }

    private fun article(path: String): ZimArticle? {
        val zim = archive ?: return null
        return runCatching {
            val entry = zim.getEntryByPath(path)
            val item = entry.getItem(true)
            val blob = item.data
            val size = blob.size()
            if (size > MAX_ARTICLE_BYTES) {
                blob.dispose()
                return null
            }
            val bytes = blob.data
            blob.dispose()
            ZimArticle(
                title = entry.title,
                path = entry.path,
                mimeType = item.mimetype,
                html = String(bytes, StandardCharsets.UTF_8)
            )
        }.getOrNull()
    }

    private fun closeCurrent() {
        runCatching { archive?.dispose() }
        archive = null
        runCatching { descriptor?.close() }
        descriptor = null
    }

    private fun displayName(context: Context, uri: Uri): String {
        return runCatching {
            context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
        }.getOrNull()?.take(180) ?: uri.lastPathSegment?.take(180) ?: "Офлайн-библиотека"
    }

}
