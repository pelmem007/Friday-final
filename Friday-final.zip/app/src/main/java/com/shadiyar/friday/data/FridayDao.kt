package com.shadiyar.friday.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface FridayDao {
    @Query("SELECT * FROM chat_messages ORDER BY createdAt DESC LIMIT 100")
    fun observeMessages(): Flow<List<ChatMessage>>

    @Query("SELECT * FROM chat_messages ORDER BY createdAt DESC LIMIT 100")
    suspend fun allMessagesForBackup(): List<ChatMessage>

    @Insert
    suspend fun insertMessage(message: ChatMessage)

    @Query("DELETE FROM chat_messages WHERE id NOT IN (SELECT id FROM chat_messages ORDER BY createdAt DESC LIMIT 100)")
    suspend fun trimMessages()

    @Transaction
    suspend fun addMessage(message: ChatMessage) {
        insertMessage(message)
        trimMessages()
    }

    @Query("SELECT * FROM knowledge_entries ORDER BY topic, title")
    fun observeKnowledge(): Flow<List<KnowledgeEntry>>

    @Query(
        "SELECT knowledge_entries.* FROM knowledge_fts " +
            "JOIN knowledge_entries ON knowledge_entries.id = knowledge_fts.rowid " +
            "WHERE knowledge_fts MATCH :matchQuery LIMIT 40"
    )
    suspend fun searchKnowledge(matchQuery: String): List<KnowledgeEntry>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertKnowledge(entry: KnowledgeEntry): Long

    @Query("SELECT COUNT(*) FROM knowledge_entries")
    suspend fun knowledgeCount(): Int

    @Query("SELECT * FROM knowledge_entries ORDER BY RANDOM() LIMIT 1")
    suspend fun randomKnowledge(): KnowledgeEntry?

    @Query("SELECT * FROM knowledge_entries WHERE topic LIKE '%' || :topic || '%' ORDER BY RANDOM() LIMIT 1")
    suspend fun randomKnowledgeInTopic(topic: String): KnowledgeEntry?

    @Query("SELECT * FROM user_facts ORDER BY updatedAt DESC")
    fun observeFacts(): Flow<List<UserFact>>

    @Query("SELECT * FROM user_facts WHERE `key` LIKE '%' || :query || '%' OR value LIKE '%' || :query || '%' LIMIT 20")
    suspend fun searchFacts(query: String): List<UserFact>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveFact(fact: UserFact)

    @Query("SELECT * FROM user_facts")
    suspend fun allFactsForBackup(): List<UserFact>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun restoreFacts(facts: List<UserFact>)

    @Query("DELETE FROM user_facts WHERE `key` = :key")
    suspend fun forgetFact(key: String): Int

    @Query("SELECT * FROM planner_items WHERE enabled = 1 ORDER BY triggerAt")
    fun observePlanner(): Flow<List<PlannerItem>>

    @Query("SELECT * FROM planner_items")
    suspend fun allPlannerForBackup(): List<PlannerItem>

    @Insert
    suspend fun insertPlanner(item: PlannerItem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun restorePlanner(items: List<PlannerItem>)

    @Query("UPDATE planner_items SET enabled = 0 WHERE id = :id")
    suspend fun disablePlanner(id: Long)

    @Query("DELETE FROM planner_items WHERE id = :id")
    suspend fun deletePlanner(id: Long)

    @Query("SELECT * FROM planner_items WHERE id = :id LIMIT 1")
    suspend fun findPlanner(id: Long): PlannerItem?

    @Query("SELECT * FROM custom_commands ORDER BY phrase")
    fun observeCustomCommands(): Flow<List<CustomCommand>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveCustomCommand(command: CustomCommand)

    @Query("SELECT * FROM custom_commands")
    suspend fun getCustomCommands(): List<CustomCommand>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun restoreCustomCommands(commands: List<CustomCommand>)

    @Query("DELETE FROM chat_messages")
    suspend fun clearMessages()

    @Query("DELETE FROM user_facts")
    suspend fun clearFacts()

    @Query("DELETE FROM planner_items")
    suspend fun clearPlanner()

    @Query("DELETE FROM custom_commands")
    suspend fun clearCommands()

    @Query("DELETE FROM knowledge_fts")
    suspend fun clearKnowledgeFts()

    @Query("DELETE FROM knowledge_entries")
    suspend fun clearKnowledge()

    @Query("DELETE FROM imported_resources")
    suspend fun clearResources()

    @Query("DELETE FROM intent_weights")
    suspend fun clearWeights()

    @Delete
    suspend fun deleteCustomCommand(command: CustomCommand)

    @Query("SELECT * FROM imported_resources ORDER BY addedAt DESC")
    fun observeResources(): Flow<List<ImportedResource>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveResource(resource: ImportedResource): Long

    @Query("UPDATE imported_resources SET isSelected = 0 WHERE kind = :kind")
    suspend fun clearSelectedResource(kind: String)

    @Query("SELECT * FROM imported_resources WHERE kind = :kind AND isSelected = 1 LIMIT 1")
    suspend fun selectedResource(kind: String): ImportedResource?

    @Query("DELETE FROM imported_resources WHERE id = :id")
    suspend fun deleteResource(id: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveWeights(weights: List<IntentWeight>)
}
