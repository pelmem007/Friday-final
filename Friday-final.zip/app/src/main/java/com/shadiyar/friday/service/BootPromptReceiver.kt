package com.shadiyar.friday.service

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.shadiyar.friday.FridayApplication
import com.shadiyar.friday.LocalErrorLog
import com.shadiyar.friday.MainActivity
import com.shadiyar.friday.data.FridayDatabase
import com.shadiyar.friday.planner.AlarmScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** После перезагрузки только показывает кнопку; микрофонный сервис автоматически не запускает. */
class BootPromptReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                FridayDatabase.get(context).dao().allPlannerForBackup()
                    .filter { it.enabled }
                    .forEach { AlarmScheduler.schedule(context, it) }
            } catch (error: Throwable) {
                LocalErrorLog.record(context, "восстановление напоминаний после перезагрузки", error)
            } finally {
                postStartNotification(context)
                pendingResult.finish()
            }
        }
    }

    private fun postStartNotification(context: Context) {
        val open = PendingIntent.getActivity(
            context,
            15,
            Intent(context, MainActivity::class.java).putExtra(MainActivity.EXTRA_START_VOICE, true),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, FridayApplication.CHANNEL_BOOT)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Пятница готова")
            .setContentText("Нажмите, чтобы открыть приложение и запустить голосовой режим.")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        runCatching { NotificationHelper.post(context, 15, notification) }
    }
}
