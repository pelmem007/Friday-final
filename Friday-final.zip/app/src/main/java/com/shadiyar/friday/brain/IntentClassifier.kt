package com.shadiyar.friday.brain

import kotlin.math.exp
import kotlin.math.ln

/** Маленький наивный Байес для русских слов. Он маршрутизирует только знакомые запросы. */
internal class IntentClassifier {
    private val samples = mapOf(
        "GREET" to listOf("привет", "здравствуй", "доброе утро", "добрый вечер"),
        "TIME" to listOf("сколько времени", "который час", "скажи время"),
        "DATE" to listOf("какая сегодня дата", "какое сегодня число", "сегодняшний день"),
        "HELP" to listOf("что ты умеешь", "помощь", "список команд"),
        "BATTERY" to listOf("сколько заряда", "заряд батареи", "процент батареи"),
        "JOKE" to listOf("расскажи шутку", "пошути", "анекдот"),
        "WHO" to listOf("кто ты", "как тебя зовут", "представься"),
        "THANKS" to listOf("спасибо", "благодарю", "молодец")
    )
    private val vocabulary = samples.values.flatten().flatMap(::tokens).toSet()

    data class Result(val label: String, val confidence: Double, val entropy: Double)

    fun classify(text: String): Result? {
        val words = tokens(text)
        if (words.isEmpty()) return null
        val labels = samples.keys.toList()
        val logScores = labels.map { label ->
            val examples = samples.getValue(label)
            val labelTokens = examples.flatMap(::tokens)
            val total = labelTokens.size
            val prior = ln(1.0 / labels.size)
            prior + words.sumOf { word ->
                ln((labelTokens.count { it == word } + 1.0) / (total + vocabulary.size))
            }
        }
        val max = logScores.maxOrNull() ?: return null
        val probs = logScores.map { exp(it - max) }
        val sum = probs.sum()
        val normalized = probs.map { it / sum }
        val best = normalized.indices.maxByOrNull { normalized[it] } ?: return null
        val entropy = -normalized.sumOf { p -> if (p <= 0) 0.0 else p * ln(p) }
        return Result(labels[best], normalized[best], entropy)
    }

    companion object {
        fun tokens(value: String): List<String> = value.lowercase()
            .split(Regex("[^а-яёa-z0-9]+"))
            .filter { it.length > 1 }
    }
}
