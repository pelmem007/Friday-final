package com.shadiyar.friday.voice

import android.content.Context
import android.net.Uri
import android.os.StatFs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipInputStream

data class ImportedModel(val directory: File, val bytesWritten: Long)

object VoskModelManager {
    private const val MAX_ARCHIVE_BYTES = 500L * 1024 * 1024
    private const val MAX_ENTRIES = 100_000
    private const val MODEL_DIR = "vosk-model"

    fun currentModel(context: Context): File? =
        File(context.filesDir, "$MODEL_DIR/conf/model.conf")
            .takeIf { it.isFile }
            ?.parentFile?.parentFile

    /** Безопасно распаковывает ZIP модели во внутреннюю память приложения. */
    suspend fun importZip(context: Context, uri: Uri): ImportedModel = withContext(Dispatchers.IO) {
        val temporary = File(context.filesDir, "vosk-model-staging")
        temporary.deleteRecursively()
        check(temporary.mkdirs()) { "Не удалось подготовить место для модели." }
        val available = StatFs(context.filesDir.absolutePath).availableBytes
        require(available >= 100L * 1024 * 1024) { "Для распаковки модели нужно освободить не менее 100 МБ." }
        var total = 0L
        var entries = 0
        try {
            val input = context.contentResolver.openInputStream(uri)
                ?: throw IllegalArgumentException("Не удалось открыть выбранный ZIP-файл.")
            ZipInputStream(input.buffered()).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    entries++
                    require(entries <= MAX_ENTRIES) { "В архиве слишком много файлов." }
                    val relative = entry.name.replace('\\', '/')
                    val components = relative.split('/').filter { it.isNotEmpty() }
                    require(
                        relative.isNotBlank() &&
                            !relative.startsWith("/") &&
                            components.isNotEmpty() &&
                            components.none { it == ".." || it == "." }
                    ) { "В архиве найден небезопасный путь." }
                    val output = File(temporary, relative).canonicalFile
                    require(output.toPath().startsWith(temporary.canonicalFile.toPath())) {
                        "Архив выходит за пределы папки модели."
                    }
                    if (entry.isDirectory) {
                        check(output.mkdirs() || output.isDirectory)
                    } else {
                        output.parentFile?.let { check(it.mkdirs() || it.isDirectory) }
                        output.outputStream().buffered().use { out ->
                            val buffer = ByteArray(64 * 1024)
                            while (true) {
                                val count = zip.read(buffer)
                                if (count < 0) break
                                total += count
                                require(total <= MAX_ARCHIVE_BYTES) {
                                    "Распакованная модель больше допустимых 500 МБ."
                                }
                                out.write(buffer, 0, count)
                            }
                        }
                    }
                    zip.closeEntry()
                    entry = zip.nextEntry
                }
            }
            val modelRoot = findModelRoot(temporary)
                ?: throw IllegalArgumentException("В архиве нет файлов модели Vosk (не найдены conf/model.conf и acoustic model).")
            val active = File(context.filesDir, MODEL_DIR)
            val replacement = File(context.filesDir, "vosk-model-ready")
            replacement.deleteRecursively()
            if (modelRoot == temporary) {
                check(temporary.renameTo(replacement)) { "Не удалось подготовить модель." }
            } else {
                modelRoot.copyRecursively(replacement, overwrite = true)
                check(replacement.isDirectory) { "Не удалось распаковать модель." }
            }
            active.deleteRecursively()
            check(replacement.renameTo(active)) { "Не удалось сохранить модель." }
            temporary.deleteRecursively()
            ImportedModel(active, total)
        } catch (error: Throwable) {
            temporary.deleteRecursively()
            throw error
        }
    }

    private fun findModelRoot(root: File): File? {
        fun search(folder: File, depth: Int): File? {
            val hasConfig = File(folder, "conf/model.conf").isFile
            val hasAcousticModel = File(folder, "am/final.mdl").isFile ||
                File(folder, "am").listFiles()?.any { it.extension == "mdl" } == true
            if (hasConfig && hasAcousticModel) return folder
            if (depth >= 3) return null
            return folder.listFiles()
                ?.asSequence()
                ?.filter(File::isDirectory)
                ?.mapNotNull { search(it, depth + 1) }
                ?.firstOrNull()
        }
        return search(root, 0)
    }
}
