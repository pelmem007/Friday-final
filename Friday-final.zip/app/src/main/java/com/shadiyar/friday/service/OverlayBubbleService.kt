package com.shadiyar.friday.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.WindowManager.LayoutParams
import com.shadiyar.friday.MainActivity

/** Не держит микрофон: это только перемещаемая кнопка для быстрого открытия приложения. */
class OverlayBubbleService : Service() {
    private class BubbleTextView(context: Context) : TextView(context) {
        override fun performClick(): Boolean {
            super.performClick()
            return true
        }
    }

    private var window: WindowManager? = null
    private var bubble: TextView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (bubble != null) return START_STICKY
        window = getSystemService(WINDOW_SERVICE) as WindowManager
        val button = BubbleTextView(this).apply {
            text = "П"
            textSize = 22f
            gravity = Gravity.CENTER
            typeface = Typeface.MONOSPACE
            setTextColor(Color.rgb(5, 18, 25))
            setBackgroundColor(Color.rgb(80, 229, 255))
            contentDescription = "Открыть Пятницу"
            setOnClickListener {
                startActivity(Intent(this@OverlayBubbleService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        }
        val layout = LayoutParams(
            56,
            56,
            LayoutParams.TYPE_APPLICATION_OVERLAY,
            LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            x = 12
        }
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        button.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = layout.x
                    startY = layout.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    layout.x = (startX + touchX - event.rawX).toInt().coerceAtLeast(0)
                    layout.y = startY + (event.rawY - touchY).toInt()
                    runCatching { window?.updateViewLayout(view, layout) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val moved = kotlin.math.abs(event.rawX - touchX) + kotlin.math.abs(event.rawY - touchY) > 12
                    if (!moved) {
                        view.performClick()
                    }
                    true
                }
                else -> false
            }
        }
        runCatching {
            window?.addView(button, layout)
            bubble = button
        }.onFailure { stopSelf() }
        return START_STICKY
    }

    override fun onDestroy() {
        bubble?.let { runCatching { window?.removeView(it) } }
        bubble = null
        window = null
        super.onDestroy()
    }
}
