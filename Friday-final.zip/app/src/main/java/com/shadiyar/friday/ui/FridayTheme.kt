package com.shadiyar.friday.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val FridayColors = darkColorScheme(
    primary = Color(0xFF50E5FF),
    onPrimary = Color(0xFF071219),
    secondary = Color(0xFF8BFFD7),
    background = Color(0xFF071219),
    surface = Color(0xFF0C1C25),
    surfaceVariant = Color(0xFF142A35),
    onBackground = Color(0xFFE0F8FF),
    onSurface = Color(0xFFE0F8FF),
    onSurfaceVariant = Color(0xFF9AB7C2),
    outline = Color(0xFF255061)
)

@Composable
fun FridayTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = FridayColors, content = content)
}
