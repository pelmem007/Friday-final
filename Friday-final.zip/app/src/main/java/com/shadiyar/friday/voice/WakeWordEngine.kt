package com.shadiyar.friday.voice

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import com.shadiyar.friday.FridayApplication
import kotlinx.coroutines.delay
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

interface WakeWordEngine {
    fun start(onCommand: (String) -> Unit, onStatus: (String) -> Unit)
    fun stop()
}

/** Два лёгких recognizer на одной модели: короткая грамматика пробуждения и обычная команда. */
class VoskWakeWordEngine(
    private val context: Context,
    private val modelDirectory: File
) : WakeWordEngine {
    private val running = AtomicBoolean(false)
    @Volatile private var recorder: AudioRecord? = null
    @Volatile private var worker: Thread? = null

    override fun start(onCommand: (String) -> Unit, onStatus: (String) -> Unit) {
        if (!running.compareAndSet(false, true)) return
        worker = Thread({
            try {
                listen(onCommand, onStatus)
            } catch (error: Throwable) {
                if (running.get()) onStatus("Микрофон остановился: ${error.message ?: "ошибка устройства"}. Нажмите «Запустить» ещё раз.")
            } finally {
                running.set(false)
                releaseRecorder()
            }
        }, "friday-voskg")
        worker?.start()
    }

    private fun listen(onCommand: (String) -> Unit, onStatus: (String) -> Unit) {
        check(context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            "Нужно разрешение на микрофон."
        }
        val model = Model(modelDirectory.absolutePath)
        val wake = Recognizer(model, 16_000.0f, "[\"пятница\", \"джарвис\", \"эй пятница\", \"[unk]\"]")
        val command = Recognizer(model, 16_000.0f)
        var commandMode = false
        var lastWakeAt = 0L
        var commandStartedAt = 0L
        var attempts = 0
        try {
            while (running.get()) {
                val min = AudioRecord.getMinBufferSize(
                    16_000,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                if (min <= 0) throw IllegalStateException("Устройство не поддерживает запись 16 кГц.")
                val audio = AudioRecord(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    16_000,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    maxOf(min * 2, 16_000)
                )
                recorder = audio
                if (audio.state != AudioRecord.STATE_INITIALIZED) {
                    audio.release()
                    recorder = null
                    attempts++
                    if (attempts >= 3) throw IllegalStateException("Микрофон занят или недоступен.")
                    onStatus("Микрофон занят. Повторная попытка ${attempts + 1} из 3…")
                    try { Thread.sleep(1_200) } catch (_: InterruptedException) { return }
                    continue
                }
                attempts = 0
                audio.startRecording()
                onStatus("Ожидаю слово «Пятница» или «Джарвис».")
                val buffer = ByteArray(4_000)
                while (running.get() && recorder === audio) {
                    val read = audio.read(buffer, 0, buffer.size)
                    if (read == AudioRecord.ERROR_DEAD_OBJECT || read == AudioRecord.ERROR_INVALID_OPERATION) break
                    if (read <= 0) continue
                    if (FridayApplication.speaker.isSpeaking) continue
                    if (!commandMode) {
                        val result = if (wake.acceptWaveForm(buffer, read)) wake.result else wake.partialResult
                        val phrase = JSONObject(result).optString(
                            if (result == wake.result) "text" else "partial"
                        ).lowercase()
                        val now = System.currentTimeMillis()
                        if ((phrase.contains("пятниц") || phrase.contains("джарвис")) && now - lastWakeAt > 1_200) {
                            lastWakeAt = now
                            commandMode = true
                            commandStartedAt = now
                            wake.reset()
                            command.reset()
                            onStatus("Слушаю команду, Сэр.")
                            FridayApplication.speaker.speak(context, "Слушаю, Сэр.")
                        }
                    } else {
                        if (command.acceptWaveForm(buffer, read)) {
                            val recognized = JSONObject(command.result).optString("text").trim()
                            if (recognized.isNotBlank()) {
                                commandMode = false
                                wake.reset()
                                command.reset()
                                onStatus("Обрабатываю команду.")
                                onCommand(recognized)
                                onStatus("Ожидаю слово активации.")
                            }
                        }
                        if (commandMode && System.currentTimeMillis() - commandStartedAt > 12_000) {
                            commandMode = false
                            command.reset()
                            wake.reset()
                            onStatus("Команда не распознана. Снова ожидаю слово активации.")
                        }
                    }
                }
                runCatching { audio.stop() }
                audio.release()
                if (recorder === audio) recorder = null
                if (running.get()) {
                    onStatus("Повторно подключаю микрофон…")
                    try { Thread.sleep(400) } catch (_: InterruptedException) { break }
                }
            }
        } finally {
            releaseRecorder()
            wake.close()
            command.close()
            model.close()
        }
    }

    override fun stop() {
        running.set(false)
        runCatching { recorder?.stop() }
        worker?.interrupt()
        worker?.join(1_500)
        worker = null
    }

    private fun releaseRecorder() {
        val audio = recorder
        recorder = null
        if (audio != null) {
            runCatching { audio.stop() }
            runCatching { audio.release() }
        }
    }
}

/** Системный распознаватель без сети, только если Android предлагает локальную русскую модель. */
object OfflineSpeechCapability {
    fun isAvailable(context: Context): Boolean =
        android.os.Build.VERSION.SDK_INT >= 31 &&
            android.speech.SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
}
