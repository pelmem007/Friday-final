package com.shadiyar.friday

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Локально сохраняет только краткие сообщения об ошибках; распознанные фразы сюда не попадают. */
object LocalErrorLog {
    private const val FILE_NAME = "friday-errors.log"
    private const val MAX_BYTES = 96 * 1024

    @Synchronized
    fun record(context: Context, source: String, error: Throwable) {
        runCatching {
            val file = File(context.applicationContext.filesDir, FILE_NAME)
            val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            val line = "[$stamp] ${source.take(60)}: ${error.javaClass.simpleName}: ${error.message.orEmpty().take(500)}\n"
            file.appendText(line, Charsets.UTF_8)
            if (file.length() > MAX_BYTES) {
                val tail = file.readLines(Charsets.UTF_8).takeLast(300).joinToString("\n", postfix = "\n")
                file.writeText(tail, Charsets.UTF_8)
            }
        }
    }

    fun read(context: Context): String {
        val file = File(context.applicationContext.filesDir, FILE_NAME)
        return if (file.isFile) runCatching { file.readText(Charsets.UTF_8) }.getOrDefault("") else ""
    }

    fun clear(context: Context) {
        runCatching { File(context.applicationContext.filesDir, FILE_NAME).delete() }
    }
}
