package com.shadiyar.friday

import android.content.Context
import com.shadiyar.friday.actions.PhoneActions
import com.shadiyar.friday.brain.LocalBrain
import com.shadiyar.friday.data.ChatMessage
import com.shadiyar.friday.data.FridayDao
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object AssistantRuntime {
    suspend fun handle(context: Context, dao: FridayDao, rawText: String): String {
        val text = rawText.trim().take(2_000)
        if (text.isBlank()) return "Слушаю, Сэр."
        return try {
            dao.addMessage(ChatMessage(role = "user", content = text))
            val reply = LocalBrain.answer(context.applicationContext, dao, text)
            val finalText = if (reply.action == null) reply.text
            else withContext(Dispatchers.Main) { PhoneActions.perform(context, reply.action) }
            dao.addMessage(ChatMessage(role = "assistant", content = finalText))
            finalText
        } catch (error: Throwable) {
            LocalErrorLog.record(context, "обработка команды", error)
            throw error
        }
    }
}
