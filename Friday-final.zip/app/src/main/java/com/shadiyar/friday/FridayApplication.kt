package com.shadiyar.friday

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

class FridayApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        createChannels()
        speaker.initialize(this)
    }

    private fun createChannels() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_VOICE, getString(R.string.service_channel_name), NotificationManager.IMPORTANCE_LOW)
        )
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_REMINDERS, getString(R.string.reminder_channel_name), NotificationManager.IMPORTANCE_HIGH)
        )
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_BOOT, "Запуск после перезагрузки", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    companion object {
        const val CHANNEL_VOICE = "friday_voice"
        const val CHANNEL_REMINDERS = "friday_reminders"
        const val CHANNEL_BOOT = "friday_boot"
        val speaker = FridaySpeaker
    }
}

/** Системный TTS с короткой очередью и русским голосом, если он установлен на устройстве. */
object FridaySpeaker {
    private val speaking = AtomicBoolean(false)
    @Volatile private var engine: TextToSpeech? = null
    @Volatile private var ready = false

    val isSpeaking: Boolean get() = speaking.get()

    fun initialize(context: Context) {
        if (engine != null) return
        engine = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) {
                engine?.language = Locale("ru", "RU")
                engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { speaking.set(true) }
                    override fun onDone(utteranceId: String?) { speaking.set(false) }
                    @Deprecated("Переопределение для совместимости с Android")
                    override fun onError(utteranceId: String?) { speaking.set(false) }
                })
            }
        }
    }

    fun speak(context: Context, text: String) {
        if (engine == null) initialize(context)
        val tts = engine ?: return
        if (!ready) return
        val settings = context.getSharedPreferences("friday_settings", Context.MODE_PRIVATE)
        tts.setSpeechRate(settings.getFloat("tts_speed", 1.0f).coerceIn(0.6f, 1.4f))
        tts.setPitch(settings.getFloat("tts_pitch", 1.0f).coerceIn(0.7f, 1.3f))
        val clean = text.take(1_000)
        tts.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "friday-${System.currentTimeMillis()}")
    }

    fun shutdown() {
        engine?.stop()
        engine?.shutdown()
        engine = null
        ready = false
        speaking.set(false)
    }
}
