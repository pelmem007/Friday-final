package com.shadiyar.friday.planner

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.shadiyar.friday.data.PlannerItem

object AlarmScheduler {
    fun schedule(context: Context, item: PlannerItem): Boolean {
        val manager = context.getSystemService(AlarmManager::class.java)
        val operation = PendingIntent.getBroadcast(
            context,
            item.id.toInt(),
            Intent(context, PlannerAlarmReceiver::class.java)
                .putExtra(PlannerAlarmReceiver.EXTRA_ITEM_ID, item.id)
                .putExtra(PlannerAlarmReceiver.EXTRA_TITLE, item.title)
                .putExtra(PlannerAlarmReceiver.EXTRA_REPEAT_MASK, item.repeatMask),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) {
                manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, item.triggerAt, operation)
                false
            } else {
                manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, item.triggerAt, operation)
                true
            }
        } catch (_: SecurityException) {
            manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, item.triggerAt, operation)
            false
        }
    }

    fun cancel(context: Context, id: Long) {
        val operation = PendingIntent.getBroadcast(
            context,
            id.toInt(),
            Intent(context, PlannerAlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        context.getSystemService(AlarmManager::class.java).cancel(operation)
    }
}
