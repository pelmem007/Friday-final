package com.shadiyar.friday.brain

import android.content.Context
import com.shadiyar.friday.data.CustomCommand
import com.shadiyar.friday.data.FridayDao
import com.shadiyar.friday.data.UserFact
import com.shadiyar.friday.planner.AlarmScheduler
import com.shadiyar.friday.planner.PlannerTextParser
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToLong

data class PhoneAction(val kind: String, val argument: String = "")
data class AssistantReply(val text: String, val action: PhoneAction? = null)

/** Правила выполняются быстро и полностью локально; неизвестный запрос не выдаётся за выполненный. */
object LocalBrain {
    private val classifier = IntentClassifier()

    suspend fun answer(context: Context, dao: FridayDao, raw: String): AssistantReply {
        var text = normalize(raw)
        text = text.replace(Regex("^(?:эй\\s+)?(?:пятница|джарвис)[, ]*"), "").trim()
        if (text.isBlank()) return AssistantReply("Слушаю, Сэр.")

        val custom = dao.getCustomCommands().firstOrNull { normalize(it.phrase) == text }
        if (custom != null) return AssistantReply(
            "Выполняю вашу команду, Сэр.",
            PhoneAction(custom.action, custom.argument)
        )

        Regex("^(?:запомни|сохрани)\\s+(.+?)\\s*(?:=|—| это | - )\\s*(.+)$").find(text)?.let {
            val key = it.groupValues[1].trim()
            val value = it.groupValues[2].trim()
            if (key.isNotBlank() && value.isNotBlank()) {
                dao.saveFact(UserFact(key = key, value = value))
                return AssistantReply("Запомнила: $key — $value, Сэр.")
            }
        }
        Regex("^(?:забудь|удали факт)\\s+(.+)$").find(text)?.let {
            val key = it.groupValues[1].trim()
            return AssistantReply(
                if (dao.forgetFact(key) > 0) "Забыла «$key», Сэр." else "Не нашла такой факт, Сэр."
            )
        }
        Regex("^(?:запиши|добавь) заметку\\s+(.+)$").find(text)?.let {
            val title = "Заметка ${SimpleDateFormat("dd.MM HH:mm", Locale("ru")).format(Date())}"
            dao.saveFact(UserFact(key = title, value = it.groupValues[1].trim()))
            return AssistantReply("Заметка сохранена, Сэр.")
        }
        Regex("^(?:найди|поищи) заметк\\S*\\s+(.+)$").find(text)?.let {
            val notes = dao.searchFacts(it.groupValues[1].trim())
            return AssistantReply(
                notes.joinToString("\n") { note -> "${note.key}: ${note.value}" }
                    .ifBlank { "Подходящих заметок не нашла, Сэр." }
            )
        }
        dao.searchFacts(text).firstOrNull { it.key.equals(text, true) }?.let {
            return AssistantReply("${it.key}: ${it.value}, Сэр.")
        }

        if (isGreeting(text)) return AssistantReply("Привет, Сэр. Чем займёмся?")
        when {
            matches(text, "как дела", "как ты", "что нового") -> return AssistantReply("Системы в норме, Сэр. Чем помочь?")
            matches(text, "кто ты", "как тебя зовут", "представься") -> return AssistantReply("Я Пятница — ваш офлайн-ассистент, Сэр.")
            matches(text, "спасибо", "благодарю") -> return AssistantReply("Всегда пожалуйста, Сэр.")
            matches(text, "пока", "до свидания") -> return AssistantReply("До связи, Сэр.")
            matches(text, "помощь", "что ты умеешь", "список команд") ->
                return AssistantReply("Умею отвечать на приветствие, считать, конвертировать величины, искать в локальных заметках и базе, ставить таймеры и напоминания, сообщать время и заряд, открывать приложения, звонить через экран набора, готовить SMS и открывать карты/настройки. Скажите «помощь», чтобы увидеть команды.")
            matches(text, "который час", "сколько времени", "скажи время", "время") ->
                return AssistantReply("Сейчас ${SimpleDateFormat("HH:mm", Locale("ru")).format(Date())}, Сэр.")
            matches(text, "какая сегодня дата", "какое сегодня число", "сегодняшняя дата", "дата") ->
                return AssistantReply("Сегодня ${SimpleDateFormat("d MMMM yyyy, EEEE", Locale("ru")).format(Date())}, Сэр.")
            matches(text, "сколько заряда", "заряд батареи", "батарея", "процент батареи") ->
                return AssistantReply("Проверяю заряд, Сэр.", PhoneAction("BATTERY"))
            matches(text, "расскажи шутку", "пошути", "анекдот", "рассмеши меня") -> {
                val joke = dao.randomKnowledgeInTopic("юмор")
                return AssistantReply(joke?.body ?: "Шуток в базе пока нет, Сэр. Импортируйте JSON-пак с юмором.")
            }
            matches(text, "расскажи цитату", "цитата", "мудрая мысль", "процитируй") -> {
                val q = dao.randomKnowledgeInTopic("цитат")
                return AssistantReply(q?.body ?: "Цитат в базе пока нет, Сэр.")
            }
            matches(text, "скажи пословицу", "пословица", "поговорка") -> {
                val q = dao.randomKnowledgeInTopic("пословиц")
                return AssistantReply(q?.body ?: "Пословиц в базе пока нет, Сэр.")
            }
            matches(text, "дай совет", "полезный совет", "лайфхак") -> {
                val q = dao.randomKnowledgeInTopic("совет")
                return AssistantReply(q?.body ?: "Советов в базе пока нет, Сэр.")
            }
            matches(text, "расскажи факт", "интересный факт", "удиви меня") -> {
                val fact = dao.randomKnowledge()
                return AssistantReply(fact?.let { "${it.title}: ${it.body}" } ?: "База знаний пуста, Сэр.")
            }
        }

        parseCalculation(text)?.let { return AssistantReply("Получается ${formatNumber(it)}, Сэр.") }
        parseConversion(text)?.let { return AssistantReply(it) }

        PlannerTextParser.parse(text)?.let { task ->
            val id = dao.insertPlanner(task.item)
            val saved = task.item.copy(id = id)
            val exact = AlarmScheduler.schedule(context, saved)
            return AssistantReply(
                if (exact) task.confirmation else "${task.confirmation} Точность будильника зависит от разрешения Android, Сэр."
            )
        }

        if (text.startsWith("открой ") || text.startsWith("запусти ")) {
            val app = text.substringAfter(' ').trim()
            return AssistantReply("Открываю приложение, Сэр.", PhoneAction("OPEN_APP", app))
        }
        Regex("^(?:позвони|набери)\\s+(.+)$").find(text)?.let {
            return AssistantReply("Открываю набор номера для ${it.groupValues[1]}, Сэр.", PhoneAction("CALL", it.groupValues[1]))
        }
        Regex("^(?:напиши|отправь)\\s+(?:смс|сообщение)\\s+(.+?)\\s+(?:текст|что)\\s+(.+)$").find(text)?.let {
            return AssistantReply("Подготовила сообщение, Сэр. Проверьте его перед отправкой.", PhoneAction("SMS", "${it.groupValues[1]}|${it.groupValues[2]}"))
        }
        Regex("^(?:маршрут до|проложи маршрут до|покажи на карте|навигация до)\\s+(.+)$").find(text)?.let {
            return AssistantReply("Открываю карту, Сэр.", PhoneAction("MAP", it.groupValues[1]))
        }
        Regex("^(?:найди в интернете|поищи в браузере|загугли|погугли)\\s+(.+)$").find(text)?.let {
            return AssistantReply("Открываю поиск. Для самих результатов нужен интернет, Сэр.", PhoneAction("WEB", it.groupValues[1]))
        }
        if (text.contains("включи фонар") || text.contains("зажги свет")) return AssistantReply("Включаю фонарик, Сэр.", PhoneAction("TORCH_ON"))
        if (text.contains("выключи фонар") || text.contains("погаси фонар")) return AssistantReply("Выключаю фонарик, Сэр.", PhoneAction("TORCH_OFF"))
        if (matches(text, "громче", "прибавь звук", "увеличь громкость")) return AssistantReply("Делаю громче, Сэр.", PhoneAction("VOLUME_UP"))
        if (matches(text, "тише", "убавь звук", "уменьши громкость")) return AssistantReply("Делаю тише, Сэр.", PhoneAction("VOLUME_DOWN"))
        if (text.contains("включи wi fi") || text.contains("включи вай фай") || text.contains("настройки wi fi"))
            return AssistantReply("Открываю настройки Wi-Fi. Android не разрешает приложению переключить его напрямую, Сэр.", PhoneAction("WIFI_SETTINGS"))
        if (text.contains("bluetooth") || text.contains("блютуз"))
            return AssistantReply("Открываю настройки Bluetooth, Сэр.", PhoneAction("BLUETOOTH_SETTINGS"))
        if (text.contains("режим полета") || text.contains("авиарежим"))
            return AssistantReply("Режим полёта можно менять только в системных настройках, Сэр.", PhoneAction("AIRPLANE_SETTINGS"))
        if (text.contains("не беспокоить") || text.contains("режим тишины"))
            return AssistantReply("Открываю системные настройки режима «Не беспокоить», Сэр.", PhoneAction("DND_SETTINGS"))
        if (text.contains("яркость"))
            return AssistantReply("Для изменения яркости дайте разрешение «Изменение системных настроек» или откройте настройки экрана, Сэр.", PhoneAction("DISPLAY_SETTINGS"))
        if (text.contains("открой youtube") || text.contains("открой ютуб"))
            return AssistantReply("Открываю YouTube, Сэр.", PhoneAction("OPEN_APP", "youtube"))
        if (text.contains("закрой приложение") || text.startsWith("закрой "))
            return AssistantReply("Android не позволяет закрывать чужие приложения программно, Сэр. Используйте список недавних приложений.")
        if (text.contains("скриншот") || text.contains("снимок экрана"))
            return AssistantReply("Системный скриншот требует подтверждения Android; откройте шторку и нажмите «Снимок экрана», Сэр.")
        if (text.contains("открой камеру") || text == "камера")
            return AssistantReply("Открываю камеру, Сэр.", PhoneAction("CAMERA"))
        if (text.contains("календар") && (text.contains("создай") || text.contains("добавь")))
            return AssistantReply("Открываю создание события в календаре, Сэр.", PhoneAction("CALENDAR", text))

        val query = safeFtsQuery(text)
        if (query.isNotBlank()) {
            val found = runCatching { dao.searchKnowledge(query) }.getOrDefault(emptyList())
            if (found.isNotEmpty()) return AssistantReply("${found.first().title}. ${found.first().body}")
        }

        val classification = classifier.classify(text)
        if (classification != null && classification.confidence >= 0.38 && classification.entropy <= 2.0) {
            return when (classification.label) {
                "GREET" -> AssistantReply("Привет, Сэр. Чем могу помочь?")
                "WHO" -> AssistantReply("Я Пятница — ваш офлайн-ассистент, Сэр.")
                "THANKS" -> AssistantReply("Всегда пожалуйста, Сэр.")
                "HELP" -> AssistantReply("Скажите «время», «дата», «сколько заряда», «поставь таймер на 5 минут», «открой YouTube» или задайте пример для вычисления, Сэр.")
                "TIME" -> AssistantReply("Сейчас ${SimpleDateFormat("HH:mm", Locale("ru")).format(Date())}, Сэр.")
                "DATE" -> AssistantReply("Сегодня ${SimpleDateFormat("d MMMM yyyy", Locale("ru")).format(Date())}, Сэр.")
                "BATTERY" -> AssistantReply("Проверяю заряд, Сэр.", PhoneAction("BATTERY"))
                "JOKE" -> AssistantReply(dao.randomKnowledgeInTopic("юмор")?.body ?: "Шуток в базе пока нет, Сэр.")
                else -> AssistantReply("Слушаю, Сэр.")
            }
        }
        val suggestion = nearestSample(text)
        return if (suggestion != null) AssistantReply("Не уверена, Сэр. Вы имели в виду «$suggestion»?")
        else AssistantReply("Пока не знаю, как выполнить это локально, Сэр. Попробуйте «помощь» или импортируйте базу знаний.")
    }

    private fun normalize(value: String): String = value.lowercase(Locale("ru"))
        .replace('ё', 'е')
        .replace(Regex("[^а-яa-z0-9+*/().,\\-\\s]"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun isGreeting(value: String): Boolean {
        val greetings = listOf("привет", "здравствуй", "доброе утро", "добрый день", "добрый вечер", "хай")
        return greetings.any { matches(value, it) } ||
            IntentClassifier.tokens(value).any { editDistance(it, "привет") <= 1 && it.length >= 5 }
    }

    private fun matches(text: String, vararg phrases: String): Boolean {
        val normalized = normalize(text)
        return phrases.any { phrase ->
            val p = normalize(phrase)
            normalized == p || normalized.startsWith("$p ") || normalized.contains(" $p ")
        }
    }

    private fun nearestSample(text: String): String? {
        val samples = listOf("привет", "который час", "какая сегодня дата", "что ты умеешь", "сколько заряда", "расскажи шутку")
        val words = IntentClassifier.tokens(text)
        return samples.minByOrNull { phrase ->
            val target = IntentClassifier.tokens(phrase)
            if (target.isEmpty()) Int.MAX_VALUE else target.minOf { t -> words.minOfOrNull { editDistance(t, it) } ?: 99 }
        }?.takeIf { phrase ->
            val target = IntentClassifier.tokens(phrase)
            target.any { t -> words.any { editDistance(t, it) <= 1 } }
        }
    }

    private fun safeFtsQuery(text: String): String = IntentClassifier.tokens(text)
        .distinct()
        .take(6)
        .joinToString(" OR ") { "\"${it.replace("\"", "\"\"")}\"" }

    private fun parseCalculation(text: String): Double? {
        val expression = text
            .replace("сколько будет", "")
            .replace("посчитай", "")
            .replace("вычисли", "")
            .replace(" плюс ", "+")
            .replace(" минус ", "-")
            .replace(" умножить на ", "*")
            .replace(" умножь на ", "*")
            .replace(" разделить на ", "/")
            .replace(" делить на ", "/")
            .trim()
        if (expression.isBlank() || !expression.any(Char::isDigit)) return null
        if (!expression.matches(Regex("[0-9+*/().,\\-\\s]+"))) return null
        return runCatching {
            ArithmeticParser(expression.replace(',', '.')).parse().takeIf { it.isFinite() }
        }.getOrNull()
    }

    private fun parseConversion(text: String): String? {
        val m = Regex("(-?\\d+(?:[.,]\\d+)?)\\s*(км|километр\\S*|м|метр\\S*|кг|килограмм\\S*|фунт\\S*|°?c|°?f)\\s*(?:в|в\\s+|to\\s+)?\\s*(км|километр\\S*|м|метр\\S*|кг|килограмм\\S*|фунт\\S*|°?c|°?f)").find(text)
            ?: return null
        val value = m.groupValues[1].replace(',', '.').toDoubleOrNull() ?: return null
        val from = m.groupValues[2]
        val to = m.groupValues[3]
        val result = when {
            from.startsWith("км") || from.startsWith("километр") -> if (to == "м" || to.startsWith("метр")) value * 1000 else return null
            (from == "м" || from.startsWith("метр")) && (to == "км" || to.startsWith("километр")) -> value / 1000
            from == "кг" || from.startsWith("килограмм") -> if (to.startsWith("фунт")) value * 2.2046226218 else return null
            from.startsWith("фунт") && (to == "кг" || to.startsWith("килограмм")) -> value / 2.2046226218
            (from == "c" || from == "°c") && (to == "f" || to == "°f") -> value * 9 / 5 + 32
            (from == "f" || from == "°f") && (to == "c" || to == "°c") -> (value - 32) * 5 / 9
            else -> return null
        }
        return "${formatNumber(result)} ${m.groupValues[3]}, Сэр."
    }

    private fun formatNumber(value: Double): String {
        val rounded = (value * 1_000_000).roundToLong() / 1_000_000.0
        return if (abs(rounded - rounded.toLong()) < 0.0000001) rounded.toLong().toString()
        else rounded.toString().replace('.', ',')
    }

    private fun editDistance(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var previous = IntArray(b.length + 1) { it }
        for (i in a.indices) {
            val current = IntArray(b.length + 1)
            current[0] = i + 1
            for (j in b.indices) {
                current[j + 1] = minOf(
                    current[j] + 1,
                    previous[j + 1] + 1,
                    previous[j] + if (a[i] == b[j]) 0 else 1
                )
            }
            previous = current
        }
        return previous[b.length]
    }
}

/** Калькулятор с приоритетом операций; eval и выполнение кода не используются. */
private class ArithmeticParser(private val source: String) {
    private var index = 0

    fun parse(): Double {
        val answer = expression()
        spaces()
        require(index == source.length)
        return answer
    }

    private fun expression(): Double {
        var value = term()
        while (true) {
            spaces()
            value = when {
                take('+') -> value + term()
                take('-') -> value - term()
                else -> return value
            }
        }
    }

    private fun term(): Double {
        var value = factor()
        while (true) {
            spaces()
            value = when {
                take('*') -> value * factor()
                take('/') -> value / factor()
                else -> return value
            }
        }
    }

    private fun factor(): Double {
        spaces()
        if (take('+')) return factor()
        if (take('-')) return -factor()
        if (take('(')) {
            val inside = expression()
            spaces()
            require(take(')'))
            return inside
        }
        val start = index
        while (index < source.length && (source[index].isDigit() || source[index] == '.')) index++
        require(index > start)
        return source.substring(start, index).toDouble()
    }

    private fun spaces() { while (index < source.length && source[index].isWhitespace()) index++ }
    private fun take(c: Char): Boolean {
        if (index >= source.length || source[index] != c) return false
        index++
        return true
    }
}
