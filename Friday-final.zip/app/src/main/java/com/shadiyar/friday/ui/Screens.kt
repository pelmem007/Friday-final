package com.shadiyar.friday.ui

import android.content.Context
import android.graphics.Color as AndroidColor
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.shadiyar.friday.data.ChatMessage
import com.shadiyar.friday.data.CustomCommand
import com.shadiyar.friday.data.FridayDao
import com.shadiyar.friday.data.ImportedResource
import com.shadiyar.friday.data.KnowledgeEntry
import com.shadiyar.friday.data.PlannerItem
import com.shadiyar.friday.LocalErrorLog
import com.shadiyar.friday.knowledge.ZimArticle
import com.shadiyar.friday.knowledge.ZimRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun ChatScreen(
    messages: List<ChatMessage>,
    status: String,
    voiceRunning: Boolean,
    onSend: (String) -> Unit,
    onVoice: () -> Unit,
    onReadLastNotification: () -> Unit
) {
    var input by rememberSaveable { mutableStateOf("") }
    Column(modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        if (messages.isEmpty()) {
            Panel(modifier = Modifier.padding(top = 10.dp)) {
                Text("На связи, Сэр.", color = MaterialTheme.colorScheme.primary, fontFamily = FontFamily.Monospace)
                Text("Напишите «привет», «открой YouTube», «таймер на 5 минут» или арифметический пример.")
            }
        }
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            reverseLayout = true,
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 12.dp)
        ) {
            items(messages, key = { it.id }) { message ->
                MessageBubble(message)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it.take(500) },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Команда, Сэр…") },
                maxLines = 3
            )
            Spacer(Modifier.width(6.dp))
            Button(
                onClick = {
                    val query = input.trim()
                    if (query.isNotBlank()) {
                        onSend(query)
                        input = ""
                    }
                },
                enabled = input.isNotBlank()
            ) { Text("↵") }
        }
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            OutlinedButton(onClick = onVoice) {
                Text(if (voiceRunning) "Остановить микрофон" else "Голос")
            }
            TextButton(onClick = onReadLastNotification) { Text("Прочитать уведомление") }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val isUser = message.role == "user"
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(0.88f),
            colors = CardDefaults.cardColors(
                containerColor = if (isUser) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
            )
        ) {
            Column(Modifier.padding(11.dp)) {
                Text(
                    if (isUser) "ВЫ" else "ПЯТНИЦА",
                    color = if (isUser) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.primary,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
                Text(message.content, modifier = Modifier.padding(top = 3.dp), fontSize = 14.sp)
            }
        }
    }
}

@Composable
fun KnowledgeScreen(
    dao: FridayDao,
    knowledge: List<KnowledgeEntry>,
    resources: List<ImportedResource>,
    onImportPack: () -> Unit,
    onPickZim: () -> Unit,
    zimTitles: List<String>,
    article: ZimArticle?,
    onFindZim: (String) -> Unit,
    onOpenZimTitle: (String) -> Unit,
    status: (String) -> Unit
) {
    var query by rememberSaveable { mutableStateOf("") }
    var results by remember { mutableStateOf(knowledge.take(35)) }
    var zimQuery by rememberSaveable { mutableStateOf("") }

    LaunchedEffect(query, knowledge) {
        delay(180)
        results = if (query.isBlank()) knowledge.take(35)
        else withContext(Dispatchers.IO) {
            val terms = ftsExpression(query)
            if (terms.isBlank()) emptyList() else runCatching { dao.searchKnowledge(terms) }.getOrDefault(emptyList())
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        SectionTitle("ЛОКАЛЬНАЯ БАЗА")
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Искать в фактах и заметках") },
            singleLine = true
        )
        Text("Записей: ${knowledge.size}. Пакеты можно пополнять файлами JSON.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onImportPack) { Text("Импорт JSON-пака") }
            OutlinedButton(onClick = onPickZim) { Text("Выбрать ZIM") }
        }
        if (resources.any { it.kind == "zim" && it.isSelected }) {
            Text("Активная офлайн-библиотека: ${resources.first { it.kind == "zim" && it.isSelected }.displayName}", color = MaterialTheme.colorScheme.secondary, fontSize = 12.sp)
        } else {
            Text("ZIM ещё не выбран. Сам файл остаётся в выбранном хранилище — приложение не копирует его.", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
        }
        results.forEach { entry ->
            Panel {
                Text(entry.topic.uppercase(Locale("ru")), color = MaterialTheme.colorScheme.secondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text(entry.title, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                Text(entry.body, fontSize = 13.sp)
            }
        }
        Panel {
            SectionTitle("РУССКАЯ WIKIPEDIA // ZIM")
            Text("Поиск выполняется по заголовкам выбранного ZIM-пака; статью можно читать внутри приложения. Для поиска текста внутри статей требуется full-text индекс в самом ZIM.", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedTextField(
                value = zimQuery,
                onValueChange = { zimQuery = it.take(100) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Название статьи") },
                singleLine = true
            )
            OutlinedButton(
                onClick = {
                    if (!ZimRepository.isOpen()) status("Сначала выберите доступный ZIM-файл, Сэр.")
                    else if (zimQuery.isBlank()) status("Введите заголовок статьи для поиска.")
                    else onFindZim(zimQuery.trim())
                }
            ) { Text("Найти статьи") }
            Text("Результаты поиска по заголовкам:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            zimTitles.forEach { title ->
                TextButton(
                    onClick = { onOpenZimTitle(title) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(title) }
            }
            if (zimTitles.isEmpty() && zimQuery.isNotBlank()) Text("Результатов пока нет.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            article?.let { ZimArticleViewer(it) }
        }
    }
}

@Composable
private fun ZimArticleViewer(article: ZimArticle) {
    Column {
        Text(article.title, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        AndroidView(
            modifier = Modifier.fillMaxWidth().height(360.dp).padding(top = 6.dp),
            factory = { context ->
                WebView(context).apply {
                    setBackgroundColor(AndroidColor.rgb(7, 18, 25))
                    settings.javaScriptEnabled = false
                    settings.allowFileAccess = false
                    settings.allowContentAccess = false
                    settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean =
                            request?.url?.host != "friday.local"

                        override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                            val uri = request?.url ?: return null
                            if (uri.host != "friday.local") {
                                return WebResourceResponse("text/plain", "UTF-8", java.io.ByteArrayInputStream(byteArrayOf()))
                            }
                            return ZimRepository.intercept(uri.encodedPath.orEmpty())
                        }
                    }
                }
            },
            update = { view ->
                if (view.tag != article.path) {
                    view.tag = article.path
                    view.loadDataWithBaseURL(
                        "https://friday.local/",
                        article.html,
                        article.mimeType.ifBlank { "text/html" },
                        "UTF-8",
                        null
                    )
                }
            }
        )
    }
}

@Composable
fun PlannerScreen(
    items: List<PlannerItem>,
    onAdd: (String, Long, Int) -> Unit,
    onDelete: (PlannerItem) -> Unit,
    onOpenExactAlarmSettings: () -> Unit
) {
    var title by rememberSaveable { mutableStateOf("") }
    var minutes by rememberSaveable { mutableStateOf("10") }
    var selectedDays by remember { mutableStateOf(setOf<Int>()) }
    val days = listOf(
        Calendar.MONDAY to "Пн",
        Calendar.TUESDAY to "Вт",
        Calendar.WEDNESDAY to "Ср",
        Calendar.THURSDAY to "Чт",
        Calendar.FRIDAY to "Пт",
        Calendar.SATURDAY to "Сб",
        Calendar.SUNDAY to "Вс"
    )
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        SectionTitle("ПЛАНИРОВЩИК")
        Panel {
            OutlinedTextField(value = title, onValueChange = { title = it.take(120) }, modifier = Modifier.fillMaxWidth(), label = { Text("Напоминание") }, singleLine = true)
            OutlinedTextField(value = minutes, onValueChange = { minutes = it.filter(Char::isDigit).take(6) }, modifier = Modifier.fillMaxWidth(), label = { Text("Через минут") }, singleLine = true)
            Text("Повторять по дням недели (необязательно)", fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                days.forEach { (day, label) ->
                    FilterChip(
                        selected = day in selectedDays,
                        onClick = {
                            selectedDays = if (day in selectedDays) selectedDays - day else selectedDays + day
                        },
                        label = { Text(label, fontSize = 10.sp) }
                    )
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    val mins = minutes.toLongOrNull()
                    if (title.isNotBlank() && mins != null && mins > 0) {
                        val mask = selectedDays.fold(0) { acc, day -> acc or (1 shl (day - Calendar.SUNDAY)) }
                        onAdd(title.trim(), mins, mask)
                        title = ""
                    }
                }, enabled = title.isNotBlank() && (minutes.toLongOrNull() ?: 0) > 0) { Text("Добавить") }
                OutlinedButton(onClick = onOpenExactAlarmSettings) { Text("Точные будильники") }
            }
        }
        if (items.isEmpty()) {
            Text("Задач пока нет.", modifier = Modifier.padding(12.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(items, key = { it.id }) { item ->
                    Panel {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(item.title, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                                Text(
                                    SimpleDateFormat("EEE, dd.MM HH:mm", Locale("ru")).format(Date(item.triggerAt)),
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            TextButton(onClick = { onDelete(item) }) { Text("Удалить") }
                        }
                    }
                }
            }
        }
    }
}

private data class ActionChoice(val id: String, val title: String)

@Composable
fun CommandsScreen(
    commands: List<CustomCommand>,
    onAdd: (String, String, String) -> Unit,
    onDelete: (CustomCommand) -> Unit
) {
    val choices = listOf(
        ActionChoice("OPEN_APP", "Открыть приложение"),
        ActionChoice("CALL", "Открыть набор номера"),
        ActionChoice("SMS", "Создать SMS"),
        ActionChoice("MAP", "Открыть карту"),
        ActionChoice("WEB", "Поиск в браузере"),
        ActionChoice("TORCH_ON", "Включить фонарик"),
        ActionChoice("TORCH_OFF", "Выключить фонарик"),
        ActionChoice("WIFI_SETTINGS", "Настройки Wi-Fi"),
        ActionChoice("BLUETOOTH_SETTINGS", "Настройки Bluetooth")
    )
    val examples = listOf(
        "Привет / здравствуй / доброе утро",
        "Который час / сколько времени",
        "Какая сегодня дата / какое число",
        "Сколько заряда / процент батареи",
        "Расскажи шутку / пошути",
        "Посчитай 28 * 4 / сколько будет 125 / 5",
        "Переведи 5 км в м / 20 °C в °F",
        "Таймер на 5 минут / напомни через 1 час",
        "Будильник на 07:30 / напомни в 18:00 купить хлеб",
        "Открой YouTube / запусти калькулятор",
        "Позвони +993… / напиши смс [номер] текст [сообщение]",
        "Маршрут до Ашхабада / найди в интернете новости"
    )
    var phrase by rememberSaveable { mutableStateOf("") }
    var argument by rememberSaveable { mutableStateOf("") }
    var selectedAction by rememberSaveable { mutableStateOf(choices.first()) }
    var menuExpanded by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SectionTitle("КОМАНДЫ")
        Panel {
            Text("Поддерживаемые команды", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Text("Это реальные действия текущей версии, а не обещание 150 универсальных команд. Некоторые системные действия требуют подтверждения Android.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            examples.forEach { Text("• $it", fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)) }
        }
        Panel {
            Text("ПОЛЬЗОВАТЕЛЬСКОЕ ПРАВИЛО", color = MaterialTheme.colorScheme.secondary, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
            Text("Если скажу X — сделай Y", fontWeight = FontWeight.SemiBold)
            OutlinedTextField(value = phrase, onValueChange = { phrase = it.take(120) }, modifier = Modifier.fillMaxWidth(), label = { Text("Фраза, которую вы скажете") }, singleLine = true)
            Box {
                OutlinedButton(onClick = { menuExpanded = true }) { Text(selectedAction.title) }
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                    choices.forEach { choice ->
                        DropdownMenuItem(
                            text = { Text(choice.title) },
                            onClick = { selectedAction = choice; menuExpanded = false }
                        )
                    }
                }
            }
            if (selectedAction.id !in setOf("TORCH_ON", "TORCH_OFF", "WIFI_SETTINGS", "BLUETOOTH_SETTINGS")) {
                OutlinedTextField(value = argument, onValueChange = { argument = it.take(250) }, modifier = Modifier.fillMaxWidth(), label = { Text("Приложение, номер или запрос") }, singleLine = true)
            }
            Button(
                onClick = {
                    onAdd(phrase.trim(), selectedAction.id, argument.trim())
                    phrase = ""
                    argument = ""
                },
                enabled = phrase.isNotBlank()
            ) { Text("Сохранить правило") }
        }
        if (commands.isNotEmpty()) {
            Text("СОХРАНЁННЫЕ ПРАВИЛА", color = MaterialTheme.colorScheme.primary, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            commands.forEach { rule ->
                Panel {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("«${rule.phrase}»", color = MaterialTheme.colorScheme.primary)
                            Text("${choices.firstOrNull { it.id == rule.action }?.title ?: rule.action} ${rule.argument}", fontSize = 11.sp)
                        }
                        TextButton(onClick = { onDelete(rule) }) { Text("Удалить") }
                    }
                }
            }
        }
    }
}

@Composable
fun SystemScreen(
    modelReady: Boolean,
    zimReady: Boolean,
    onStartVoice: () -> Unit,
    onRequestOverlay: () -> Unit,
    onStopOverlay: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenExactAlarms: () -> Unit,
    onBattery: () -> Unit,
    onBatteryOptimization: () -> Unit,
    onAutoStartHelp: () -> Unit
) {
    val context = LocalContext.current
    val runtime = Runtime.getRuntime()
    var showAutoStartHelp by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SectionTitle("СИСТЕМА / ДИАГНОСТИКА")
        Panel {
            Text("Устройство", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Text("${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}", fontSize = 12.sp)
            Text("Android ${android.os.Build.VERSION.RELEASE} / API ${android.os.Build.VERSION.SDK_INT}", fontSize = 12.sp)
            Text("Доступная память процесса: ${((runtime.maxMemory() - runtime.totalMemory() + runtime.freeMemory()) / (1024 * 1024))} МБ из ${runtime.maxMemory() / (1024 * 1024)} МБ", fontSize = 11.sp)
            Text("Сеть не нужна для локальных команд. Браузер, карты и установку модели открывайте только по своему желанию.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Panel {
            StatusRow("Модель Vosk", if (modelReady) "УСТАНОВЛЕНА" else "НЕ УСТАНОВЛЕНА")
            StatusRow("Офлайн-библиотека ZIM", if (zimReady) "ВЫБРАНА" else "НЕ ВЫБРАНА")
            Button(onClick = onStartVoice) { Text("Запустить / остановить голос") }
        }
        Panel {
            Text("Разрешения и фон", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            SystemAction("Плавающая кнопка", "Нужен доступ «Поверх других окон». Она только открывает приложение.") { onRequestOverlay() }
            OutlinedButton(onClick = onStopOverlay) { Text("Остановить плавающую кнопку") }
            SystemAction("Чтение уведомлений", "Доступ выдаётся вручную в настройках Android.") { onOpenNotifications() }
            SystemAction("Точные будильники", "Android может переносить напоминания без специального разрешения.") { onOpenExactAlarms() }
            SystemAction("Оптимизация батареи", "Исключение из оптимизации расходует больше заряда.") { onBatteryOptimization() }
            SystemAction("Автозапуск Infinix XOS", "Покажет путь к настройкам автозапуска.") {
                showAutoStartHelp = true
                onAutoStartHelp()
            }
            OutlinedButton(onClick = onBattery) { Text("Проверить заряд") }
            Text("После перезагрузки приложение показывает уведомление с кнопкой. Android 15 запрещает автоматически запускать микрофонный сервис из BOOT_COMPLETED.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    if (showAutoStartHelp) {
        AlertDialog(
            onDismissRequest = { showAutoStartHelp = false },
            title = { Text("Настройки Infinix XOS") },
            text = { Text("Откройте Настройки → Приложения → Пятница → Батарея/Управление питанием. Разрешите автозапуск, работу в фоне и отключите оптимизацию для Пятницы. Точные названия разделов зависят от версии XOS.") },
            confirmButton = { TextButton(onClick = { showAutoStartHelp = false }) { Text("Понятно") } }
        )
    }
}

@Composable
private fun SystemAction(title: String, details: String, action: () -> Unit) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text(details, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 10.sp)
            }
            TextButton(onClick = action) { Text("Открыть") }
        }
    }
}

@Composable
fun SettingsScreen(
    resources: List<ImportedResource>,
    speakReplies: Boolean,
    onSpeakRepliesChanged: (Boolean) -> Unit,
    onImportModel: () -> Unit,
    onImportZim: () -> Unit,
    onImportPack: () -> Unit,
    onExport: () -> Unit,
    onImport: () -> Unit,
    onReset: () -> Unit,
    status: String
) {
    val context = LocalContext.current
    val preferences = remember(context) { context.getSharedPreferences("friday_settings", Context.MODE_PRIVATE) }
    var speed by remember { mutableStateOf(preferences.getFloat("tts_speed", 1.0f)) }
    var pitch by remember { mutableStateOf(preferences.getFloat("tts_pitch", 1.0f)) }
    var selectedEngine by remember { mutableStateOf(preferences.getString("speech_engine", "vosk") ?: "vosk") }
    var showErrorLog by remember { mutableStateOf(false) }
    val errorLog = remember(showErrorLog) { if (showErrorLog) LocalErrorLog.read(context) else "" }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        SectionTitle("НАСТРОЙКИ")
        Panel {
            Text("Голосовой ввод", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = selectedEngine == "vosk", onClick = {
                    selectedEngine = "vosk"
                    preferences.edit().putString("speech_engine", selectedEngine).apply()
                }, label = { Text("Vosk офлайн") })
                FilterChip(selected = selectedEngine == "android", onClick = {
                    selectedEngine = "android"
                    preferences.edit().putString("speech_engine", selectedEngine).apply()
                }, label = { Text("Android офлайн") })
            }
            Text("Android SpeechRecognizer доступен только если на устройстве установлена локальная русская модель. Постоянное слово активации работает через Vosk.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = onImportModel) { Text("Импортировать ZIP-модель Vosk") }
        }
        Panel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Озвучивать ответы", fontWeight = FontWeight.SemiBold)
                    Text("Русский системный TTS, если он установлен.", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(checked = speakReplies, onCheckedChange = onSpeakRepliesChanged)
            }
            Text("Скорость: ${"%.1f".format(Locale.US, speed)}", fontSize = 12.sp)
            Slider(value = speed, onValueChange = { speed = it }, valueRange = 0.6f..1.4f, onValueChangeFinished = { preferences.edit().putFloat("tts_speed", speed).apply() })
            Text("Высота тона: ${"%.1f".format(Locale.US, pitch)}", fontSize = 12.sp)
            Slider(value = pitch, onValueChange = { pitch = it }, valueRange = 0.7f..1.3f, onValueChangeFinished = { preferences.edit().putFloat("tts_pitch", pitch).apply() })
        }
        Panel {
            Text("ОФЛАЙН-ФАЙЛЫ", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Text("Vosk распаковывается во внутреннюю память приложения. ZIM открывается с выбранного файла без копирования; для чтения он должен оставаться доступен.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = onImportZim) { Text("Выбрать / заменить ZIM") }
            OutlinedButton(onClick = onImportPack) { Text("Импортировать JSON-пак базы") }
            resources.forEach { resource ->
                Text("${resource.kind.uppercase(Locale("ru"))}: ${resource.displayName} (${resource.sizeBytes / (1024 * 1024)} МБ)", fontSize = 11.sp)
            }
        }
        Panel {
            Text("РЕЗЕРВНАЯ КОПИЯ", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Text("Экспортируются последние сообщения, заметки/факты, задачи и пользовательские команды. Модель, ZIM и разрешения телефона в копию не входят.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onExport) { Text("Экспорт") }
                OutlinedButton(onClick = onImport) { Text("Импорт") }
            }
        }
        Panel {
            Text("ЛОКАЛЬНЫЕ ДАННЫЕ", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            Text("Сброс удаляет пользовательские данные и локальную модель. Встроенные факты восстановятся при следующем запуске.", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick = onReset) { Text("Полный сброс") }
            OutlinedButton(onClick = { showErrorLog = true }) { Text("Журнал ошибок") }
        }
        Text(status, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    if (showErrorLog) {
        AlertDialog(
            onDismissRequest = { showErrorLog = false },
            title = { Text("Локальный журнал ошибок") },
            text = { Text(errorLog.ifBlank { "Ошибок пока не записано." }, fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
            confirmButton = { TextButton(onClick = { showErrorLog = false }) { Text("Закрыть") } }
        )
    }
}

@Composable
private fun StatusRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontSize = 12.sp)
        Text(value, color = MaterialTheme.colorScheme.secondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = MaterialTheme.colorScheme.primary, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
}

@Composable
private fun Panel(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) { content() }
    }
}

private fun ftsExpression(text: String): String = text
    .lowercase(Locale("ru"))
    .split(Regex("[^а-яёa-z0-9]+"))
    .filter { it.length > 1 }
    .distinct()
    .take(8)
    .joinToString(" OR ") { "\"${it.replace("\"", "\"\"")}\"" }
