# Сохраняем JNI-обёртки Vosk и libkiwix: нативные библиотеки обращаются к этим классам по именам.
-keep class org.vosk.** { *; }
-keep class org.kiwix.libzim.** { *; }
-keepclasseswithmembernames class * { native <methods>; }
-keep class com.sun.jna.** { *; }
-dontwarn com.sun.jna.**
